local disabled = table.set()

Hooks:PostHook(PerpetualEventManager, "init_finalize", "PerpetualEventManager_init_finalize_TimelessEventItems", function(self)
	local events = Global.perpetual_manager.events

	for event_id, event_data in pairs(events) do
		local upgrades = event_data and event_data.upgrades or {}

		for _, upgrade in ipairs(upgrades) do
			if disabled[upgrade] then
				managers.upgrades:unaquire(upgrade, "PerpetualEventManager")
			else
				managers.upgrades:aquire(upgrade, false, "PerpetualEventManager")
			end
		end
	end
end)

function PerpetualEventManager:has_event_upgrade(upgrade)
	return not disabled[upgrade]
end