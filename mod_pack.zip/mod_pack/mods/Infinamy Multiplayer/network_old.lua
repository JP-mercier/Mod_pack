-- Old version of network.lua
-- Sends a chat message to a hidden channel containing the 'true unlimited infamy value'
-- Problem: chat messages are not 'ordered' (as defined in network.network_settings)
-- Special care must be taken in case we receive the chat message first or the 'lobby_info' first

if RequiredScript == "lib/network/base/handlers/connectionnetworkhandler" then
    _G.infinamyReceivedRanks = {}
    local function patchRank(originalFunction, globalTable, rankIndex, args)
        local peer = args[1]._verify_sender(args[#args])
        if peer then
            if _G.infinamyReceivedRanks[peer:id()] then
                -- we already received correct rank, patch rank then call original function
                args[rankIndex] = math.max(args[rankIndex], _G.infinamyReceivedRanks[peer:id()])
                originalFunction(unpack(args))
            else
                -- no rank data received yet
                if args[rankIndex] > 500 then
                    -- wait until we receive the correct infamy value
                    globalTable[peer:id()] = args
                    return
                else
                    -- low infamy, no special handling necessary
                    originalFunction(unpack(args))
                end
            end
        end
    end

    _G.infinamyReceivedLobbyInfo = {}
    local original_lobby_info = ConnectionNetworkHandler.lobby_info
    function ConnectionNetworkHandler:lobby_info(level, rank, stinger_index, character, mask_set, sender)
        local args = {self, level, rank, stinger_index, character, mask_set, sender}
        patchRank(original_lobby_info, _G.infinamyReceivedLobbyInfo, 3, args)
    end

    _G.infinamyReceivedSyncProfile = {}
    local original_sync_profile = ConnectionNetworkHandler.sync_profile
    function ConnectionNetworkHandler:sync_profile(level, rank, sender)
        local args = {self, level, rank, sender}r
        patchRank(original_sync_profile, _G.infinamyReceivedSyncProfile, 3, args)
    end

elseif RequiredScript == "lib/network/base/networkpeer" then

    local function receivedCorrectRank(handlerName, globalTable, data, sender)
        local rank = tonumber(data)
        local peer = NetworkHelper:GetPeers()[sender]
        if rank and peer then
            -- save correct infamy value
            _G.infinamyReceivedRanks[peer:id()] = rank
            -- 
            local args = globalTable[peer:id()]
            if args then
                -- call connection handler that was previously skipped
                ConnectionNetworkHandler[handlerName](unpack(args))
                globalTable[peer:id()] = nil
            end
        end
    end
    
    NetworkHelper:AddReceiveHook("Infinamy_lobby_info", "Infinamy_lobby_info_receiver", function(data, sender)
        receivedCorrectRank("lobby_info", _G.infinamyReceivedLobbyInfo, data, sender)
    end)
    NetworkHelper:AddReceiveHook("Infinamy_sync_profile", "Infinamy_sync_profile_receiver", function(data, sender)
        receivedCorrectRank("sync_profile", _G.infinamyReceivedSyncProfile, data, sender)
    end)

    Hooks:PostHook(NetworkPeer, "_send_queued", "infinamy_send_queued", function(peer, queue_name, func_name, level, rank, ...)
        if func_name == "sync_profile" or func_name == "lobby_info" then
            NetworkHelper:SendToPeer(peer:id(), "Infinamy_" .. func_name, rank)
        end
    end)
end