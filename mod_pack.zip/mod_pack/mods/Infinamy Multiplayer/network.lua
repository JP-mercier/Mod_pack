-- The 'lobby_info' message has an unused string field 'mask_set'
-- We can use it to send the infamy value as string, bypassing any parameter limit
-- Vanilla clients will just ignore the parameter

if RequiredScript == "lib/network/base/handlers/connectionnetworkhandler" then

    -- receive true rank as string in 'mask_set'
    local original_lobby_info = ConnectionNetworkHandler.lobby_info
    function ConnectionNetworkHandler:lobby_info(level, rank, stinger_index, character, mask_set, sender)
        if mask_set and tonumber(mask_set) then
            rank = tonumber(mask_set)
        end
        original_lobby_info(self, level, rank, stinger_index, character, mask_set, sender)
    end

    -- overwrite received rank with previously received true rank
    local original_sync_profile = ConnectionNetworkHandler.sync_profile
    function ConnectionNetworkHandler:sync_profile(level, rank, sender)
        local peer = self._verify_sender(sender)
        if peer then
            rank = math.max(rank, peer:rank())
        end
        original_sync_profile(self, level, rank, sender)
    end

elseif RequiredScript == "lib/network/base/networkpeer" then

    -- when sending 'lobby_info', send 'rank' as string via 'mask_set'
    local original_send = NetworkPeer.send
    local function send_lobby_info(peer, level, rank, stinger_index, character, mask_set)
        mask_set = tostring(rank)
        original_send(peer, "lobby_info", level, rank, stinger_index, character, mask_set)
    end
    function NetworkPeer:send(func_name, ...)
        if func_name == "lobby_info" then
            send_lobby_info(self, ...)
        else
            original_send(self, func_name, ...)
        end
    end

end