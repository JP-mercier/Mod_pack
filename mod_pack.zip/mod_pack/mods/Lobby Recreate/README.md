# Lobby Recreate

A SuperBLT mod for PAYDAY 2 that leaves the current multiplayer lobby, hosts a new one with the same contract and settings, and sends a lobby invite to every player who was in the old one. It can be triggered by the host or by a client.

It is meant for the case where a lobby gets into a bad state: players stop being able to load in, or can no longer see each other. The usual fix is to leave, host again and re-invite everyone by hand. This mod does that with one menu button.

Only the player who presses the key needs the mod. Other players only have to accept the invite.

## Requirements

- PAYDAY 2 (Steam)
- [SuperBLT](https://superblt.znix.xyz/)

## Installation

Copy the `Lobby Recreate` folder into `PAYDAY 2/mods/`, so the layout is:

```
PAYDAY 2/mods/Lobby Recreate/mod.txt
PAYDAY 2/mods/Lobby Recreate/lua/core.lua
PAYDAY 2/mods/Lobby Recreate/lua/keybind.lua
```

No keybind is needed. An optional one can be set under **Options > Mod Keybinds > Recreate Lobby**.

## Usage

1. When the lobby breaks, select **Recreate Lobby**:
   - Pre-game lobby: in the menu on the right, just above **Leave this lobby**.
   - Briefing screen (loadout/planning after loading in): press Escape, it is just above **Quit to main menu**.
2. Confirm the dialog. It lists the players who will be invited.
3. The new lobby opens with you as the host, and invites go out a few seconds later.

The button is only shown when it can be used: online, not Crime Spree or Holdout, and, on the briefing screen, only on day 1 of the job (recreating restarts the job from day 1). It is never shown during a heist.

From the briefing screen the mod first quits to the main menu (the same path as **Quit to main menu**), waits for the menu to finish loading, then hosts the new lobby.

### Host vs client

| Triggered by | Old lobby                                                | Who is invited                          | Settings source                         |
|--------------|----------------------------------------------------------|-----------------------------------------|-----------------------------------------|
| Host         | Closed. Everyone sees "host left".                       | All other players                       | Your own `Global.game_settings`         |
| Client       | You leave it. The old host and other players stay in it. | The old host and all other players      | The old host's Steam lobby data         |

As a client, you become the host of the new lobby. The old lobby keeps running until its players accept your invite or leave.

## How it works

The mod hooks two game scripts:

| Hook                                  | Purpose                                               |
|---------------------------------------|-------------------------------------------------------|
| `lib/managers/menumanager`            | Add the menu buttons, resume a recreate after quitting from the briefing, detect when the new lobby has finished being created. |
| `lib/network/base/basenetworksession` | Track which players have been in the lobby.           |

### Menu button

On `MenuManagerBuildCustomMenus`, an item named `lobby_recreate_btn` is inserted into two nodes:

| Node    | Placed above the first item whose name, `text_id` or callback contains |
|---------|-------------------------------------------------------------------------|
| `lobby` | `leave`                                                                 |
| `pause` | `end_game`, then `quit`, then `leave`                                   |

If no anchor is found, the item goes at the end of the node and the node's item names are logged. The item's `visible()` runs the same checks as the recreate itself, so the button is hidden whenever it would fail.

### Sequence

1. **Validate.** The mod checks that the game is in `menu_main` or `ingame_waiting_for_players` (day 1 only), an online session exists, a Steam lobby handler exists, and the lobby is not Crime Spree or Holdout.
2. **Snapshot.** It records `managers.job:current_job_id()`, `Global.game_settings.difficulty` and `Global.game_settings.one_down`, and builds the invite list. The host sends these three values to every client (`ConnectionNetworkHandler:sync_game_settings`), so they are correct in both roles.
   - As host, the other settings (permission, reputation limit, drop-in, kick option, job plan) are read from `Global.game_settings` when the new lobby is built, so they carry over without being copied.
   - As client, `Global.game_settings` holds your own hosting preferences, not the host's. The mod reads `permission`, `drop_in`, `kick_option` and `job_plan` from the old host's Steam lobby data (`NetworkMatchMakingSTEAM:get_lobby_data()`) instead.
3. **Announce.** It sends a normal chat message to all peers so players without the mod know an invite is coming.
4. **Leave.** From the briefing screen, the job, settings and invite list are stored in `Global.lobby_recreate_pending` (loading the main menu reloads all Lua), then after 1 second it calls `MenuCallbackHandler:_dialog_end_game_yes()`. Once the game is back in `menu_main` with no session, it waits 2 s and continues at step 6 (abandoned after 90 s). From the lobby, after 1 second it calls `MenuCallbackHandler:_dialog_leave_lobby_yes()`. This is the same path as the in-game "Leave lobby" confirmation: it sends `set_peer_left` to peers and runs `MenuManager:on_leave_lobby()`, which also leaves the Steam lobby.
5. **Wait for teardown.** It polls every 0.25 s until `managers.network:session()` is `nil`. The game only closes a session once every peer has an RPC connection and has finished loading outfit assets (`BaseNetworkSession:is_ready_to_close()`). A player stuck mid-connection, which is the situation this mod exists for, can hold that up indefinitely. After 8 s the mod calls `managers.network:stop_network(true)` itself. After 16 s it gives up and reports an error.
6. **Re-host.** As client, it first writes the saved host settings into `Global.game_settings` (`permission`, `drop_in_option`, `drop_in_allowed`, `kick_option`, `job_plan`). It then calls `MenuCallbackHandler:start_job()` with the saved job, which goes through `NetworkMatchMakingSTEAM:create_lobby()` exactly as picking a contract on Crime.net does. If the old lobby had no contract (for example one created by an empty-lobby mod), it calls `MenuCallbackHandler:create_lobby()` instead.
7. **Invite.** A post-hook on `MenuManager:created_lobby()` detects the new lobby. After 1.5 s, which gives Steam time to publish the lobby data, each saved player is invited to the new lobby ID.

### Invite mechanism

Invites use the same lookup as the in-game Social Hub (`SocialHubManager:invite_user_to_lobby`):

- If the user is a platform (Steam) friend, `Distribution:user_from_id(id):invite(lobby_id)`
- Otherwise, `DistributionMatchmaking:user_from_id(id):invite(lobby_id)`
- Fallback: `Steam:user(id):invite(lobby_id)`

If any invite throws, the mod opens the Steam overlay invite dialog (`NetworkMatchMakingSTEAM:invite_friends_to_lobby()`) so the host can invite the rest by hand.

### Who gets invited

The mod keeps a roster keyed by peer `user_id`, as host and as client. It is stored in `Global.lobby_recreate_roster` so it survives loading into the briefing. Each entry is tagged with the ID of the Steam lobby it was seen in, and only entries from the current lobby are used. Joining or hosting a different lobby therefore does not carry old players over.

| Event                                             | Roster effect             |
|---------------------------------------------------|---------------------------|
| `BaseNetworkSession:add_peer`                     | Added                     |
| `BaseNetworkSession:remove_peer`, reason `"lost"` | Kept (connection dropped) |
| `BaseNetworkSession:remove_peer`, reason `"left"` | Removed (left on purpose) |
| `BaseNetworkSession:on_peer_kicked`               | Removed                   |
| A lobby hosted normally (not by this mod)         | Roster cleared            |

The invite list is every current peer (the host included, when triggered as a client) plus every roster entry for the current lobby, minus the local player and anyone in the session's kicked list. Roster changes are ignored while a recreate is running, so the teardown of the old session does not wipe it. Invited players are re-tagged with the new lobby ID, so recreating again re-invites them too.

### Timings

| Constant         | Value | Meaning                                                           |
|------------------|-------|-------------------------------------------------------------------|
| `LEAVE_DELAY`    | 1 s   | Delay between the chat announcement and leaving                   |
| `LEAVE_TIMEOUT`  | 8 s   | Time before the old session is force-stopped (abort at 2x)        |
| `CREATE_TIMEOUT` | 20 s  | Time allowed for the new lobby to be created before reporting an error |
| `INVITE_DELAY`   | 1.5 s | Delay between lobby creation and sending invites                  |

## Limitations

- As host, every player is briefly disconnected. The mod replaces the Steam lobby and the connections between players, which is the actual fix, so this cannot be avoided. It only automates getting everyone back.
- As client, the old lobby is not closed. Players who do not accept the invite stay in it with the old host.
- As client, the old host's permission, drop-in, kick option and job plan are written into your `Global.game_settings`, so they become your hosting defaults until you change them. The reputation limit is not copied; your own setting is used.
- Players have to accept the invite. Joining automatically would require the mod on every client.
- It does not work during a heist, on the briefing of day 2 or later, between days of a multi-day job, in Crime Spree or in Holdout.
- Recreating from the briefing screen goes through the main menu, so it takes a few seconds longer than from the lobby.
- Steam may not deliver invites to users who are not on your friends list.
- Contract-specific extras that Crime.net attaches (such as heat bonuses) are not preserved. The job ID, difficulty and One Down setting are.

## Troubleshooting

All mod output goes to the SuperBLT log in `PAYDAY 2/mods/logs/` with the prefix `[Lobby Recreate]`. Failures also show an in-game dialog explaining what to do next.

## Files

| File              | Description                                                   |
|-------------------|---------------------------------------------------------------|
| `mod.txt`         | SuperBLT manifest: hooks and optional keybind definition      |
| `lua/core.lua`    | Recreate flow, menu buttons, roster tracking and hooks        |
| `lua/keybind.lua` | Optional keybind entry point, calls `LobbyRecreate:request()` |
