# Post Heist Skip

PAYDAY 2 SuperBLT mod. One key (Backspace by default) for the end of a heist: it skips the XP screen, picks your card, and as host takes everyone back to the lobby once the card drops have been rolled.

Other players don't need the mod.

## What a press does

| Screen | Host | Client |
|---|---|---|
| XP screen (success) | Continues at once, without waiting for the experience animation or the 1.5 s block | Nothing to skip (only the host can leave this screen). A chat line says your card will be picked when the host continues |
| XP screen (failed heist) | Back to the lobby (Enter would retry) | Nothing |
| Card screen | Picks the highlighted card, then back to the lobby | Picks the highlighted card |

You only need to press once. The key arms the skip, and the mod carries it through every screen: a host press on the XP screen also picks the card and returns to the lobby. A client press on the XP screen picks the card as soon as the host moves everyone to the card screen.

Single player ends the game the same way Enter does. On day 1 of a multi-day job, it only skips the XP screen, and the next day starts as usual.

## Waiting for card drops

Your card item is added to your inventory when the drop is rolled, not when the card flips. The roll can wait on the Steam inventory callback, so before leaving, the host waits for:

- **its own drop**, up to 10 s;
- **the teammates' drops** (they arrive over the network as `feed_lootdrop`), up to 3 s after its own. Press the key again to stop waiting for them.

This usually takes a fraction of a second.

## Install

Copy the `Post Heist Skip` folder into `PAYDAY 2/mods/`. Requires [SuperBLT](https://superblt.znix.xyz/).

## Keybind

Mod Options > Keybinds > **Post heist skip**. It is bound to Backspace when left empty (BLT doesn't save empty binds, so clearing it brings Backspace back). Like every BLT keybind, it does nothing while you're typing in chat.

## How it works

- `MissionEndState`: waits until `_total_xp_bonus` has been handed out (on the state's first update), then sets `_completion_bonus_done`, clears `_continue_block_timer` and calls the state's own `continue()`. The usual checks still apply (menu in focus, no dialog, no stats screen, chat not focused).
- Card screen: the pick is the same as `LootDropScreenGui:confirm_pressed()` before a card is chosen (`choose_card` plus the `choose_lootcard` sync). The own-drop check is a post-hook on `IngameLobbyMenuState:set_lootdrop`. The teammate check reads `wait_for_lootdrop` from the loot screen HUD's peer data.
- Leaving is the same as the host's Enter on the card screen: `set_server_joinable(true)`, then `MenuCallbackHandler:load_start_menu_lobby()`.

Works alongside speedyxp.
