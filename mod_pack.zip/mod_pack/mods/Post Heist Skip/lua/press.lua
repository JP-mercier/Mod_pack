if PostHeistSkip then
	PostHeistSkip:press()
end
