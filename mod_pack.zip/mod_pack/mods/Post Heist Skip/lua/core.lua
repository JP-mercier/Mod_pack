-- Post Heist Skip
-- One key press arms the skip; GameSetupUpdate then carries it through the end screens:
--   XP screen (host)   -> continue as soon as the XP has been handed out (no animation wait)
--   XP screen (fail)   -> host goes back to the lobby instead of retrying
--   card screen        -> pick the highlighted card, then (host) back to the lobby once
--                         our own drop is rolled and teammates' drops arrived (max TEAM_WAIT s)
-- Clients cannot leave the XP screen (the host moves everyone), so for them the press
-- only picks the card once they reach the card screen.

PostHeistSkip = PostHeistSkip or {}
local PHS = PostHeistSkip

PHS.TEAM_WAIT = 3   -- seconds to wait for teammates' drops after ours is ready
PHS.DROP_WAIT = 10  -- seconds to wait for our own drop (Steam inventory callback) before leaving anyway

local END_SCREENS = { victoryscreen = true, gameoverscreen = true }
local CARD_SCREEN = "ingame_lobby_menu"

local function state_name()
	return game_state_machine and game_state_machine:current_state_name()
end

local function is_host()
	return Network:is_server() or Global.game_settings.single_player
end

local function dialog_open()
	return managers.system_menu and managers.system_menu:is_active()
end

function PHS:_reset()
	self._armed = false
	self._force = false
	self._card_seen_t = nil
	self._own_ready_t = nil
	self._told_client = nil
end

function PHS:_say(text)
	if managers.chat and ChatManager then
		managers.chat:_receive_message(ChatManager.GAME, "Post Heist Skip", text, tweak_data.system_chat_color)
	end
end

function PHS:press()
	if self._left then
		return
	end

	local name = state_name()

	if not END_SCREENS[name] and name ~= CARD_SCREEN then
		return
	end

	if self._armed then
		-- Second press: stop waiting for teammates' cards.
		self._force = true
	else
		self:_reset()
		self._armed = true
	end

	self:step(Application:time())
end

function PHS:step(now)
	if not self._armed or self._left then
		return
	end

	local name = state_name()
	local state = game_state_machine:current_state()

	if END_SCREENS[name] then
		self:_end_screen(state, name)
	elseif name == CARD_SCREEN then
		self:_card_screen(state, now)
	else
		-- Retry, next day, or anything else: nothing left to skip.
		self:_reset()
	end
end

-- XP screen ---------------------------------------------------------------

function PHS:_end_screen(state, name)
	if not is_host() then
		if not self._told_client then
			self._told_client = true
			self:_say("Your card will be picked when the host continues.")
		end

		return
	end

	-- XP is handed out on the state's first update after at_enter; never leave before that.
	if state._total_xp_bonus then
		return
	end

	if dialog_open() or managers.hud:showing_stats_screen() then
		return
	end

	if managers.menu:active_menu() ~= state._mission_end_menu then
		return
	end

	if managers.menu_component:input_focus() == true then
		return
	end

	if name == "gameoverscreen" then
		self:_leave()

		return
	end

	-- Same as Enter, minus the "calculating experience" animation and the 1.5 s block.
	state._completion_bonus_done = true
	state._continue_block_timer = nil

	state:continue()
end

-- Card screen -------------------------------------------------------------

function PHS:_pick_card()
	local gui = managers.menu_component and managers.menu_component._lootdrop_gui

	if not gui or gui._card_chosen or gui._no_loot_for_me or not alive(gui._panel) then
		return gui
	end

	local selected = gui._selected

	if type(selected) ~= "number" or selected < 1 or selected > 3 then
		selected = 2
	end

	-- Same as LootDropScreenGui:confirm_pressed() before a card is chosen.
	gui._card_chosen = true

	managers.menu_component:post_event("menu_enter")
	gui:choose_card(gui._id, selected)

	if not Global.game_settings.single_player and managers.network:session() then
		managers.network:session():send_to_peers("choose_lootcard", selected)
	end

	return gui
end

function PHS:_team_ready()
	local session = managers.network:session()
	local hud = managers.hud.get_lootscreen_hud and managers.hud:get_lootscreen_hud()

	if not session or not hud or type(hud._peer_data) ~= "table" then
		return true
	end

	for _, peer in pairs(session:peers()) do
		local data = hud._peer_data[peer:id()]

		if type(data) == "table" and data.wait_for_lootdrop then
			return false
		end
	end

	return true
end

function PHS:_card_screen(state, now)
	if not managers.job:is_job_finished() then
		-- Not the last day: the host's game starts the next day by itself.
		self:_reset()

		return
	end

	local gui = self:_pick_card()

	if not is_host() then
		if gui then
			self:_reset()
		end

		return
	end

	if dialog_open() then
		return
	end

	self._card_seen_t = self._card_seen_t or now

	-- Our drop is added to the inventory when it is rolled (set_lootdrop), which can
	-- wait on the Steam inventory callback. Leaving earlier would lose it.
	local own_ready = state._phs_drop_set and not state._mass_drop_data

	if not own_ready and now - self._card_seen_t < self.DROP_WAIT then
		return
	end

	self._own_ready_t = self._own_ready_t or now

	if not self._force and not self:_team_ready() and now - self._own_ready_t < self.TEAM_WAIT then
		return
	end

	self:_leave()
end

-- Leaving -----------------------------------------------------------------

function PHS:_leave()
	self:_reset()
	self._left = true

	if Global.game_settings.single_player then
		MenuCallbackHandler:_dialog_end_game_yes()

		return
	end

	-- Same as IngameLobbyMenuState:continue() for the host (and the "terminate" chat command).
	if managers.network:session() and Network:is_server() then
		managers.network.matchmake:set_server_joinable(true)
	end

	MenuCallbackHandler:load_start_menu_lobby()
end

-- Hooks -------------------------------------------------------------------

if not PHS._update_hooked then
	PHS._update_hooked = true

	Hooks:Add("GameSetupUpdate", "PostHeistSkip_GameSetupUpdate", function(t, dt)
		if PHS._armed then
			PHS:step(Application:time())
		end
	end)
end

if RequiredScript == "lib/states/ingamelobbymenu" then
	Hooks:PostHook(IngameLobbyMenuState, "set_lootdrop", "PostHeistSkip_set_lootdrop", function(self)
		self._phs_drop_set = true
	end)
end
