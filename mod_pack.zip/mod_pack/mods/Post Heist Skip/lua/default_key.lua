-- Bind the keybind to Backspace when the player has not bound it to anything.
-- BLT only saves non-empty binds, so an unbound key always comes back as Backspace.
local bind = BLT and BLT.Keybinds and BLT.Keybinds:get_keybind("post_heist_skip")

if bind and not bind:HasKey() then
	bind:SetKey("backspace")
end
