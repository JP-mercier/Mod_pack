# Chat Input Fix

PAYDAY 2 SuperBLT mod. Keeps the chat box you are typing in visible, and carries a message you have not sent yet over to the next screen instead of hiding or losing it.

Local only: nothing extra is sent over the network, and other players don't need the mod.

## Problems it fixes

1. **End screens.** You start typing on the XP screen, the game moves to the payday (card) screen, and the text is still in the box but the box can't be seen. Your next message is sent with the old text in front of it. Every screen change re-applies the chat's position preset (`ChatGui:set_params`), which drops the box to layer 20 while it still has keyboard focus.
2. **Screen changes close the chat.** Going from the lobby to the loadout screen, into the heist, or to the end screen closes the chat box and throws away what you were typing (`ChatGui:hide()` clears the text, and the menu/heist reload drops everything else).
3. **Drop-in pause.** While the "PLAYER is joining N%" dialog is up you can type, but you can't see the box. The drop-in pauses the game (`Application:set_pause(true)`), which stops the box's fade-in animation at alpha 0, and the dialog (layer 1100) is on the same layer as the focused heist chat.

## What it does

- **While you type**, the chat box is kept above dialogs (layer 1150; dialogs are 1100, the mouse pointer 1200) and drawn at full opacity. This is checked every frame, including paused frames.
- **Unsent text** is saved in `Global` as you type, so it survives the menu/heist reload. If the box closes for any reason other than you, the next chat that becomes usable reopens with the text after 0.75 s, so you can keep typing:
  - in a heist: in-game play states only, with no menu or dialog open;
  - in menus (lobby, loadout, end screens): when the chat is enabled and shown, and no dialog is open.
- These close the chat on purpose and discard the saved text: **Enter** (send), **Esc**, and clicking outside the menu chat.
- If the heist chat still has focus when a menu takes over (end of heist), it is released and the end-screen chat takes the text.

Limits: saved text is dropped after 180 s without typing, and the same text is reopened at most 5 times.

## Install

Copy the `Chat Input Fix` folder into `PAYDAY 2/mods/`. Requires [SuperBLT](https://superblt.znix.xyz/).

## Compatibility

- Works with the vanilla chat and with VanillaHUD Plus's heist chat (multi-line input is kept).
- Patches `ChatGui` and `HUDChat` by wrapping these methods: `update_caret`, `set_layer`, `_on_focus`, `enter_key_callback`, `esc_key_callback`, and `ChatGui.mouse_pressed`. Mods that replace those methods outright after this one loads will turn parts of it off.
- The per-frame check runs inside `pcall`. After an error it disables itself and writes the error to the BLT log.

## Log

Each time a chat is reopened, a line is written to the BLT log:

```
[Chat Input Fix] reopened menu chat with unsent text (12 chars)
```

## Known limitation

The heist chat (with VanillaHUD Plus) accepts several lines, but the menu chat shows only one. If a long message moves from the heist to a menu chat, your next keystroke cuts it down to the line you can see (that's how the game handles input that overflows the box).
