-- Chat Input Fix
--
-- Two chat boxes exist: ChatGui (menus, lobby, briefing, end screens) and
-- HUDChat (in heist). This file patches both.
--
-- 1. Visibility. While you type, the box is kept on top and fully opaque:
--    - Switching end screens re-applies the chat preset, which drops the
--      layer to 20 while you are still typing (ChatGui:set_params).
--    - The drop-in "is joining X%" pause freezes the fade-in animation and the
--      dialog (layer 1100) sits on the box (HUDChat focus layer is 1100 too).
--    Layers while typing are raised to 1150 (dialogs 1100, mouse 1200) and
--    the input/output panels are forced to alpha 1.
--
-- 2. Unsent message carry-over. Text you were typing is remembered in Global
--    (survives the menu <-> heist reload). If the box closes for any reason
--    other than you (Enter, Esc, clicking outside the menu chat), the next
--    chat that becomes usable reopens with that text.

ChatInputFix = ChatInputFix or {}
local CIF = ChatInputFix

CIF.TOP_LAYER = 1150      -- tweak_data.gui.DIALOG_LAYER = 1100, MOUSE_LAYER = 1200
CIF.SETTLE_TIME = 0.75    -- seconds a chat must stay usable before it is reopened
CIF.MAX_AGE = 180         -- seconds; a draft not touched for longer is dropped
CIF.MAX_RESTORES = 5      -- reopen attempts per draft without new typing

-- Player states where the heist chat can be reopened.
CIF.HUD_STATES = {
	ingame_standard = true,
	ingame_mask_off = true,
	ingame_clean = true,
	ingame_civilian = true,
	ingame_bleed_out = true,
	ingame_fatal = true,
	ingame_arrested = true,
	ingame_incapacitated = true,
	ingame_electrified = true,
	ingame_waiting_for_respawn = true,
	ingame_driving = true,
	ingame_parachuting = true,
	ingame_freefall = true
}

local function draft()
	Global.chat_input_fix = Global.chat_input_fix or {}

	return Global.chat_input_fix
end

local function input_text(chat)
	local panel = chat and chat._input_panel

	if not alive(panel) then
		return nil
	end

	return panel:child("input_text")
end

-- Record what is being typed. Called after every update_caret.
function CIF.note(chat)
	if not chat._focus then
		return
	end

	local text = input_text(chat)

	if not text then
		return
	end

	local s = text:text()
	local d = draft()

	if s == "" then
		d.text = nil
		d.restores = 0
	elseif s ~= d.text then
		d.text = s
		d.restores = 0
	end

	d.time = os.time()
end

-- The user ended the message (sent it, Esc, clicked away).
function CIF.drop()
	local d = draft()

	d.text = nil
	d.restores = 0
end

-- Show the box at full opacity, immediately (animations may be frozen).
function CIF.keep_visible(chat)
	if not chat._focus or not alive(chat._panel) then
		return
	end

	local input = chat._input_panel

	if alive(input) and input:alpha() < 1 then
		input:stop()
		input:set_alpha(1)
	end

	local output = chat._panel:child("output_panel")

	if output and output:alpha() < 1 then
		output:stop()
		chat:set_output_alpha(1)
	end
end

function CIF.set_input(chat, s)
	local text = input_text(chat)

	if not text then
		return
	end

	text:set_text(s)

	local n = utf8.len(s)

	text:set_selection(n, n)

	-- VanillaHUD Plus multi-line heist input
	if chat._set_input_lines then
		local lines = #text:line_breaks()

		if HUDChat and HUDChat.MAX_INPUT_LINES then
			lines = math.min(lines, HUDChat.MAX_INPUT_LINES)
		end

		chat:_set_input_lines(lines)
	end

	chat:update_caret()
end

------------------------------------------------------------------------------
-- Class patches
------------------------------------------------------------------------------

local function patch(class)
	if not class or class._cif_patched then
		return
	end

	class._cif_patched = true

	local orig_update_caret = class.update_caret

	function class:update_caret(...)
		local r = orig_update_caret(self, ...)

		CIF.note(self)

		return r
	end

	local orig_set_layer = class.set_layer

	function class:set_layer(layer, ...)
		if self._focus and type(layer) == "number" and layer < CIF.TOP_LAYER then
			layer = CIF.TOP_LAYER
		end

		return orig_set_layer(self, layer, ...)
	end

	local orig_on_focus = class._on_focus

	function class:_on_focus(...)
		local r = orig_on_focus(self, ...)

		CIF.keep_visible(self)

		return r
	end

	local orig_enter = class.enter_key_callback

	function class:enter_key_callback(...)
		local r = orig_enter(self, ...)

		CIF.drop()

		return r
	end

	local orig_esc = class.esc_key_callback

	function class:esc_key_callback(...)
		local r = orig_esc(self, ...)

		CIF.drop()

		return r
	end
end

if string.lower(RequiredScript) == "lib/managers/chatmanager" then
	if ChatGui and not ChatGui._cif_patched then
		patch(ChatGui)

		-- Clicking outside the menu chat closes it on purpose.
		local orig_mouse_pressed = ChatGui.mouse_pressed

		function ChatGui:mouse_pressed(...)
			local was_focused = self._focus

			local function after(...)
				if was_focused and not self._focus then
					CIF.drop()
				end

				return ...
			end

			return after(orig_mouse_pressed(self, ...))
		end
	end
elseif string.lower(RequiredScript) == "lib/managers/hud/hudchat" then
	patch(HUDChat)
end

------------------------------------------------------------------------------
-- Per-frame guard
------------------------------------------------------------------------------

local function system_menu_active()
	return managers.system_menu and managers.system_menu:is_active()
end

local function menu_active()
	return managers.menu and managers.menu:active_menu() and true or false
end

local function menu_chat()
	local mc = managers.menu_component
	local chat = mc and mc._game_chat_gui

	if chat and alive(chat._panel) and alive(chat._input_panel) then
		return chat
	end
end

local function hud_chat()
	local hud = managers.hud
	local chat = hud and hud._hud_chat

	if chat and alive(chat._panel) and alive(chat._input_panel) then
		return chat
	end
end

local function menu_chat_usable(chat)
	if not chat or chat._focus or not chat:enabled() or not chat._panel:visible() then
		return false
	end

	if not menu_active() or system_menu_active() or not managers.network:session() then
		return false
	end

	local hchat = hud_chat()

	if hchat and hchat._focus then
		return false
	end

	return managers.menu_component:input_focus() ~= true
end

local function hud_chat_usable(chat)
	local hud = managers.hud

	if not chat or chat._focus or chat ~= hud._hud_chat_ingame or hud:chat_focus() then
		return false
	end

	if menu_active() or system_menu_active() or not managers.network:session() then
		return false
	end

	if Global.hud_disabled or hud:showing_stats_screen() then
		return false
	end

	local state = game_state_machine and game_state_machine:current_state_name()

	if not state or not CIF.HUD_STATES[state] then
		return false
	end

	local info = PlayerBase and PlayerBase.PLAYER_INFO_HUD_PD2
	local full = PlayerBase and PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2

	return info and full and hud:alive(full) and hud:exists(info) and hud:visible(info) and true or false
end

local settle_since, settle_target

function CIF.update()
	local mchat = menu_chat()
	local hchat = hud_chat()
	local focused = false

	-- 1. A box you are typing in: keep it visible, or release it if its
	--    screen is gone (the text stays in the draft and moves on).
	if mchat and mchat._focus then
		if not mchat:enabled() or not mchat._panel:visible() then
			mchat:_loose_focus()
		else
			focused = true

			CIF.keep_visible(mchat)
		end
	end

	if hchat and hchat._focus then
		if menu_active() then
			-- heist ended / menu took over while typing in the heist chat
			if managers.hud:chat_focus() then
				managers.hud:set_chat_focus(false)
			end

			-- set_chat_focus does nothing once the heist HUD is unloaded
			if hchat._focus then
				hchat:_loose_focus()
			end

			focused = true
		else
			focused = true

			CIF.keep_visible(hchat)
		end
	end

	-- 2. Reopen an unsent message in the next usable chat.
	local d = draft()

	if focused or not d.text then
		settle_since = nil

		return
	end

	if d.time and os.time() - d.time > CIF.MAX_AGE or (d.restores or 0) >= CIF.MAX_RESTORES then
		CIF.drop()

		settle_since = nil

		return
	end

	local target = hud_chat_usable(hchat) and "hud" or menu_chat_usable(mchat) and "menu" or nil

	if not target then
		settle_since = nil

		return
	end

	local now = os.clock()

	if not settle_since or settle_target ~= target then
		settle_since = now
		settle_target = target

		return
	end

	if now - settle_since < CIF.SETTLE_TIME then
		return
	end

	settle_since = nil
	d.restores = (d.restores or 0) + 1
	d.time = os.time()

	local text = d.text

	if target == "hud" then
		managers.hud:set_chat_skip_first(false)
		managers.hud:set_chat_focus(true)

		if hchat._focus then
			CIF.set_input(hchat, text)
		end
	else
		mchat:open_page()

		if mchat._focus then
			CIF.set_input(mchat, text)
		end
	end

	log("[Chat Input Fix] reopened " .. target .. " chat with unsent text (" .. tostring(utf8.len(text)) .. " chars)")
end

local function safe_update()
	if CIF.failed then
		return
	end

	local ok, err = pcall(CIF.update)

	if not ok then
		CIF.failed = true

		log("[Chat Input Fix] disabled after error: " .. tostring(err))
	end
end

Hooks:Add("MenuUpdate", "ChatInputFix_MenuUpdate", safe_update)
Hooks:Add("GameSetupUpdate", "ChatInputFix_GameSetupUpdate", safe_update)
Hooks:Add("GameSetupPausedUpdate", "ChatInputFix_GameSetupPausedUpdate", safe_update)
