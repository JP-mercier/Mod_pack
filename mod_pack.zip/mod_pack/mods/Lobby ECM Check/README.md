# Lobby ECM Check

SuperBLT add-on for PAYDAY 2. Shows which lobby players have ECM Specialist aced
(pager-blocking ECMs). Display only: it sends nothing over the network.

Works on its own. With Lobby Player Info installed, it also corrects that mod's team skills box.
It loads after Lobby Player Info (`priority: -1`) and wraps its functions without editing its
files, so a Lobby Player Info update won't remove it.

## What you see

Under each player in the lobby:

| Tag | Meaning |
|---|---|
| `PAGERS x2` (yellow) | Aced for sure. Number of ECMs they're bringing |
| `PAGERS? x2` (orange) | Their skill points allow the ace, but it isn't proven |
| `NO PAGERS x2` (grey) | Bringing ECMs that won't block pagers |
| nothing | Not aced, and not bringing ECMs |

In Lobby Player Info's team box (Ghost row), each ECM Specialist icon gets a bar in its
owner's name color. Unconfirmed icons are dimmed with a `?`. Disproven ones turn grey.

## Why Lobby Player Info gets it wrong

The lobby only syncs **points spent per subtree**, not which skills were bought. Lobby
Player Info shows a yellow ECM icon for anyone with 28+ points in Shinobi. But you can
spend up to 38 points in Shinobi without the ace: tiers 1-3 fully aced cost 34, plus 4 for
ECM Specialist basic.

## Verdict rules

| Evidence | Verdict |
|---|---|
| Yourself | exact (your own upgrades) |
| Shinobi < 28 | no (ace needs tier 4 at 16-18 points + 12) |
| Shinobi > 38 | yes |
| Seen in a previous heist, same skill points | remembered yes/no |
| ECMs in main deployable slot, count 1 | no (Specialist basic gives the 2nd) |
| Otherwise | maybe |

Evidence collected in heists (same sources as ECM Rush Announcer):

- `sync_upgrade ecm_jammer affects_pagers` from that player: yes
- their spawn upgrade burst ends (3 s) without it: no
- level 3 ECM placed: yes. Level 1: no. Level 2 proves nothing.

Saved per Steam ID and skill points string in `mods/saves/lobby_ecm_check.json`. A respec
changes the string, so old verdicts stop applying.
