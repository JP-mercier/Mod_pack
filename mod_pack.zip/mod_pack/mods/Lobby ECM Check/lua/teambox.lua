local key = ModPath .. "	" .. RequiredScript
if _G[key] then return else _G[key] = true end

if not _G.LobbyECMCheck then
	dofile(ModPath .. "lua/core.lua")
end

-- Lobby Player Info defines its team box in this same hook; this mod loads after it (priority -1).
if not _G.LPITeamBox then
	return
end

local ICON_SIZE = 20
local MAYBE_ALPHA = 0.35

local orig_rebuild = LPITeamBox.RebuildData
function LPITeamBox:RebuildData(skills)
	orig_rebuild(self, skills)
	LobbyECMCheck:tag_team_icons(self._team_icons, skills or self._skills)
end

local orig_update = LPITeamBox.Update
function LPITeamBox:Update(...)
	-- Same filter as Lobby Player Info's icon loop, so the nth icon drawn maps back to its entry.
	local drawn = {}
	local tree = LobbyECMCheck:shinobi_tree()
	local row = tree and self._team_icons and self._team_icons[LobbyECMCheck:tree_line(tree)]
	for _, icon in ipairs(row or {}) do
		if not (LobbyPlayerInfo.settings.team_skills_mode == 3 and icon.color_idx == 3) then
			table.insert(drawn, icon)
		end
	end
	self._ecm_check_drawn = drawn

	return orig_update(self, ...)
end

local orig_icon = LPITeamBox.CreateTeamSkillIcon
function LPITeamBox:CreateTeamSkillIcon(line, nth, color, tree_id)
	local tree = LobbyECMCheck:shinobi_tree()
	local icon = tree_id == tree and line == LobbyECMCheck:tree_line(tree) and self._ecm_check_drawn and self._ecm_check_drawn[nth + 1]
	if not icon or icon.tree ~= tree or not icon.peer_id then
		return orig_icon(self, line, nth, color, tree_id)
	end

	local maybe = icon.ecm == LobbyECMCheck.MAYBE
	orig_icon(self, line, nth, maybe and color:with_alpha(MAYBE_ALPHA) or color, tree_id)

	-- Same spot Lobby Player Info drew the icon.
	local left = self._ts_trees_text:right() + 4 + ICON_SIZE * nth
	local lh = self._ts_trees_text:h() / 5
	local top = self._ts_trees_text:top() + (line - 1) * lh + (lh - ICON_SIZE) / 2

	-- Owner's name color under the icon.
	self._team_skills_panel:rect({
		color = tweak_data.chat_colors[icon.peer_id] or Color.white,
		layer = 0,
		x = left + 3,
		y = top + ICON_SIZE - 3,
		w = ICON_SIZE - 6,
		h = 2
	})

	if maybe then
		self._team_skills_panel:text({
			text = "?",
			font = tweak_data.menu.pd2_small_font,
			font_size = tweak_data.menu.pd2_small_font_size - 2,
			color = LobbyECMCheck.COLORS.maybe,
			align = "center",
			vertical = "center",
			layer = 0,
			x = left,
			y = top,
			w = ICON_SIZE,
			h = ICON_SIZE
		})
	end
end
