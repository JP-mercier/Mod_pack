-- Lobby ECM Check: works out who has ECM Specialist aced (the only source of pager jamming).
-- Loaded (once) by every other script in this mod.

if _G.LobbyECMCheck then
	return
end

LobbyECMCheck = {}
LobbyECMCheck._memory_path = SavePath .. "lobby_ecm_check.json"

LobbyECMCheck.YES = "yes"
LobbyECMCheck.MAYBE = "maybe"
LobbyECMCheck.NO = "no"

-- The lobby only knows points spent per subtree, never which skills were bought.
-- Shinobi tiers 1-3 fully aced cost 4 + 2*6 + 2*9 = 34, and ECM Specialist basic adds 4: up to 38 without the ace.
-- The ace needs tier 4 unlocked (18 points, 16 with the Ghost infamy discount) plus 4 + 8: at least 28.
LobbyECMCheck.MIN_ACED_POINTS = 28
LobbyECMCheck.MAX_UNACED_POINTS = 38
-- Lobby Player Info hides the subtree icon at 19 points or less.
LobbyECMCheck.LPI_ICON_POINTS = 20
LobbyECMCheck.FULL_TREE_POINTS = 46
-- ECMs start at 1 and only ECM Specialist basic adds one. A Jack of All Trades second deployable
-- rounds both 1 and 2 to 1, so only the main deployable slot tells them apart.
LobbyECMCheck.UNSKILLED_ECM_COUNT = 1
-- A player's synced upgrades are all sent in one burst when their unit spawns.
LobbyECMCheck.UPGRADE_BURST_WINDOW = 3

-- Steam id -> { [points string] = true/false }, learned in heists and kept between sessions.
LobbyECMCheck._memory = {}
-- Per heist (the Lua state reloads between heists).
LobbyECMCheck._heist_pagers = {}
LobbyECMCheck._heist_burst = {}

----------------------------------------------------------------
-- Memory
----------------------------------------------------------------
function LobbyECMCheck:load_memory()
	local file = io.open(self._memory_path, "r")
	if not file then
		return
	end
	local ok, data = pcall(json.decode, file:read("*all"))
	file:close()
	if ok and type(data) == "table" then
		self._memory = data
	end
end

function LobbyECMCheck:save_memory()
	local file = io.open(self._memory_path, "w+")
	if file then
		file:write(json.encode(self._memory))
		file:close()
	end
end

----------------------------------------------------------------
-- Skill points
----------------------------------------------------------------
-- Index of the subtree topped by ECM Specialist (Shinobi).
function LobbyECMCheck:shinobi_tree()
	if not self._shinobi_tree then
		for tree, data in ipairs(tweak_data.skilltree.trees) do
			local top = data.tiers and data.tiers[#data.tiers]
			if top and table.contains(top, "ecm_2x") then
				self._shinobi_tree = tree
				break
			end
		end
	end
	return self._shinobi_tree
end

-- Row of Lobby Player Info's team box (one per skill tree) that holds this subtree.
function LobbyECMCheck:tree_line(tree)
	return math.floor((tree - 1) / 3) + 1
end

-- The "points per subtree" half of a peer's skills string, e.g. "0_12_..._28_...".
function LobbyECMCheck:points_string(peer)
	local skills = peer and peer:skills()
	local points = skills and string.split(skills, "-")[1]
	if points and points ~= "" then
		return points
	end
end

function LobbyECMCheck:shinobi_points(points_string)
	local tree = self:shinobi_tree()
	return tree and points_string and tonumber(string.split(points_string, "_")[tree])
end

-- ECMs this player brings, from their loadout.
function LobbyECMCheck:loadout_ecms(peer)
	local outfit = peer:blackmarket_outfit()
	if not outfit then
		return 0
	end
	if outfit.deployable == "ecm_jammer" then
		return outfit.deployable_amount or 0
	end
	if outfit.secondary_deployable == "ecm_jammer" then
		return outfit.secondary_deployable_amount or 0
	end
	return 0
end

----------------------------------------------------------------
-- Verdict
----------------------------------------------------------------
-- YES / MAYBE / NO, or nil if their skills haven't synced yet.
function LobbyECMCheck:status(peer)
	local session = managers.network and managers.network:session()
	if not peer or not session then
		return nil
	end

	if peer == session:local_peer() then
		return managers.player:has_category_upgrade("ecm_jammer", "affects_pagers") and self.YES or self.NO
	end

	local points = self:points_string(peer)
	local shinobi = self:shinobi_points(points)
	if not shinobi then
		return nil
	end
	if shinobi < self.MIN_ACED_POINTS then
		return self.NO
	end
	if shinobi > self.MAX_UNACED_POINTS then
		return self.YES
	end

	local known = self._memory[peer:user_id() or ""]
	known = known and known[points]
	if known ~= nil then
		return known and self.YES or self.NO
	end

	local outfit = peer:blackmarket_outfit()
	if outfit and outfit.deployable == "ecm_jammer" and outfit.deployable_amount == self.UNSKILLED_ECM_COUNT then
		return self.NO
	end

	return self.MAYBE
end

----------------------------------------------------------------
-- In-heist evidence
----------------------------------------------------------------
-- Remembers the verdict for this player's current skill points.
function LobbyECMCheck:learn(peer, aced)
	local session = managers.network and managers.network:session()
	if not peer or not session or peer == session:local_peer() then
		return
	end

	local key = peer:user_id()
	local points = self:points_string(peer)
	if not key or not points then
		return
	end

	if aced then
		self._heist_pagers[key] = true
	elseif self._heist_pagers[key] then
		-- Proof of the ace this heist beats any "no".
		return
	end

	local known = self._memory[key] or {}
	if known[points] == aced then
		return
	end
	known[points] = aced
	self._memory[key] = known
	self:save_memory()
end

-- Called for every upgrade another player syncs, even ones vanilla drops.
-- No affects_pagers in a player's spawn burst means they don't have it.
function LobbyECMCheck:on_upgrade_sync(peer, category, upgrade)
	if not peer then
		return
	end

	if category == "ecm_jammer" and upgrade == "affects_pagers" then
		self:learn(peer, true)
		return
	end

	local key = peer:user_id()
	if key and not self._heist_burst[key] then
		self._heist_burst[key] = true
		DelayedCalls:Add("LobbyECMCheckBurst" .. key, self.UPGRADE_BURST_WINDOW, function()
			self:learn(peer, false)
		end)
	end
end

-- Duration level = 1 + ECM Overdrive basic + ECM Specialist aced.
function LobbyECMCheck:on_ecm_placed(peer_id, upgrade_lvl)
	local session = managers.network and managers.network:session()
	local peer = session and peer_id and peer_id > 0 and session:peer(peer_id)
	if not peer then
		return
	end

	if upgrade_lvl == 3 then
		self:learn(peer, true)
	elseif upgrade_lvl == 1 then
		self:learn(peer, false)
	end
end

----------------------------------------------------------------
-- Lobby Player Info team box
----------------------------------------------------------------
-- Swaps Lobby Player Info's Shinobi entries for ones that know their owner and verdict.
function LobbyECMCheck:tag_team_icons(icons, skills)
	local tree = self:shinobi_tree()
	local session = managers.network and managers.network:session()
	local row = tree and icons and icons[self:tree_line(tree)]
	if not row or not session then
		return
	end

	for i = #row, 1, -1 do
		if row[i].tree == tree then
			table.remove(row, i)
		end
	end

	for peer_id, points in pairs(skills or {}) do
		local peer = session:peer(peer_id)
		local shinobi = self:shinobi_points(points)
		if peer and shinobi and shinobi >= self.LPI_ICON_POINTS then
			local status = self:status(peer)
			local color_idx = 3
			if status == self.YES or status == self.MAYBE then
				color_idx = shinobi == self.FULL_TREE_POINTS and 1 or 2
			end
			table.insert(row, {
				tree = tree,
				color_idx = color_idx,
				peer_id = peer_id,
				ecm = status
			})
		end
	end

	table.sort(row, function(a, b)
		if a.color_idx ~= b.color_idx then
			return a.color_idx < b.color_idx
		elseif a.tree ~= b.tree then
			return a.tree < b.tree
		elseif (a.ecm == self.MAYBE) ~= (b.ecm == self.MAYBE) then
			-- Confirmed before unconfirmed.
			return b.ecm == self.MAYBE
		end
		return (a.peer_id or 0) < (b.peer_id or 0)
	end)
end

----------------------------------------------------------------
-- Per-player tag
----------------------------------------------------------------
LobbyECMCheck.COLORS = {
	yes = Color("ffd300"),
	maybe = Color("ff8c00"),
	no = Color("ababab")
}

-- "PAGERS x2", "PAGERS? x2", or "NO PAGERS x2" for someone bringing ECMs that won't block pagers.
function LobbyECMCheck:tag_text(peer)
	local status = self:status(peer)
	local ecms = self:loadout_ecms(peer)
	local count = ecms > 0 and (" x" .. ecms) or " (no ECMs)"

	if status == self.YES then
		return "PAGERS" .. count, self.COLORS.yes
	elseif status == self.MAYBE then
		return "PAGERS?" .. count, self.COLORS.maybe
	elseif status == self.NO and ecms > 0 then
		return "NO PAGERS" .. count, self.COLORS.no
	end
end

LobbyECMCheck:load_memory()
