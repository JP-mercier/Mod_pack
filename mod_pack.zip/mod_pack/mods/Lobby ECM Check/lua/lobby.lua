local key = ModPath .. "	" .. RequiredScript
if _G[key] then return else _G[key] = true end

if not _G.LobbyECMCheck then
	dofile(ModPath .. "lua/core.lua")
end

local ICON_SIZE = 16
local GAP = 2

local orig_init = LobbyCharacterData.init
function LobbyCharacterData:init(...)
	orig_init(self, ...)

	local icon_xy = tweak_data.skilltree.skills.ecm_2x.icon_xy
	self._ecm_check_icon = self._panel:bitmap({
		texture = "guis/textures/pd2/skilltree_2/icons_atlas_2",
		texture_rect = { icon_xy[1] * 80, icon_xy[2] * 80, 80, 80 },
		w = ICON_SIZE,
		h = ICON_SIZE,
		blend_mode = "add",
		layer = 0,
		visible = false
	})
	self._ecm_check_text = self._panel:text({
		text = "",
		font = tweak_data.menu.pd2_small_font,
		font_size = tweak_data.menu.pd2_small_font_size - 4,
		layer = 0,
		visible = false
	})
end

-- Runs after Lobby Player Info has laid out its own lines, so the tag goes right under its skills.
local orig_update = LobbyCharacterData.update_character
function LobbyCharacterData:update_character(...)
	orig_update(self, ...)

	if not self._ecm_check_text or not self:_can_update() then
		return
	end

	local text, color = LobbyECMCheck:tag_text(self._peer)
	self._ecm_check_icon:set_visible(text ~= nil)
	self._ecm_check_text:set_visible(text ~= nil)
	if not text then
		return
	end

	self._ecm_check_text:set_text(text)
	self._ecm_check_text:set_color(color)
	self._ecm_check_icon:set_color(color)
	local _, _, w, h = self._ecm_check_text:text_rect()
	self._ecm_check_text:set_size(w, h)

	local above = self._peer_skills or self._state_text
	local left = above:center_x() - (ICON_SIZE + GAP + w) / 2
	local top = above:bottom() + GAP
	self._ecm_check_icon:set_left(left)
	self._ecm_check_icon:set_center_y(top + h / 2)
	self._ecm_check_text:set_left(self._ecm_check_icon:right() + GAP)
	self._ecm_check_text:set_top(top)
end
