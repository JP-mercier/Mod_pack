if not _G.LobbyECMCheck then
	dofile(ModPath .. "lua/core.lua")
end

-- Vanilla drops sync_upgrade when it doesn't know the sender's unit yet (common between two clients),
-- so record it before that check.
Hooks:PreHook(UnitNetworkHandler, "sync_upgrade", "LobbyECMCheckSyncUpgrade", function(self, category, upgrade, level, sender)
	LobbyECMCheck:on_upgrade_sync(self._verify_sender(sender), category, upgrade)
end)
