---@class BLTMod
---@field new fun(self, identifier: string, data: nil, path: string):BLTMod, boolean
BLTMod = blt_class()
BLTMod.enabled = true
BLTMod._enabled = true
BLTMod.safe_mode = true

function BLTMod:init(identifier, data, path)
	-- Kept the data argument to not change the function signature in case for some reason there's a mod out there that creates BLTMod instances
	if data then
		BLT:DeprecationWarning("BLTMod.init with data")
	elseif io.file_is_readable(path .. "mod.txt") then
		data = io.load_as_json(path .. "mod.txt")
	elseif io.file_is_readable(path .. "mod.json") then
		data = io.load_as_json(path .. "mod.json")
	end

	self.supermod_definition = data and data.supermod_definition or "supermod.xml"
	if not data and not io.file_is_readable(path .. self.supermod_definition) then
		return false
	elseif not data then
		data = {} -- If we have no mod.txt but a supermod.xml, initialize empty data
	end

	self._errors = {}
	self._legacy_updates = {}

	-- Mod information
	self.id = identifier
	self.json_data = data
	self.raw_data = data
	self.path = path

	-- Set up the supermod instance
	self.supermod = BLTSuperMod.try_load(self, self.supermod_definition)

	self.name = data.name or identifier
	self.desc = data.description or "No description"
	self.version = data.version or "1.0"
	self.blt_version = data.blt_version or "1.0"
	self.author = data.author or "Unknown"
	self.contact = data.contact or "N/A"
	self.priority = tonumber(data.priority) or 0
	self.dependencies = data.dependencies or {}
	self.color = data.color or nil
	self.image_path = data.image or nil
	self.disable_safe_mode = data.disable_safe_mode or false
	self.undisablable = data.undisablable or false
	self.library = data.is_library or false
	self.vr_disabled = data.vr_disabled or false
	self.desktop_disabled = data.desktop_disabled or false
	self.needs_restart = data.needs_restart or nil
	self.updates = {}

	-- Process the update data
	for _, update_data in ipairs(self.raw_data.updates or {}) do
		local new_update, valid = BLTUpdate:new(self, update_data)
		if valid and new_update:IsPresent() then
			table.insert(self.updates, new_update)
		elseif not valid and update_data.identifier then
			self._legacy_updates[update_data.identifier] = true
		end
	end

	-- Return wether the mod is valid (allowed to run in VR/Non-VR)
	local is_vr = BLT:IsVr()
	return is_vr and not self.vr_disabled or not is_vr and not self.desktop_disabled
end

function BLTMod:Setup()
	BLT:Log(LogLevel.INFO, string.format("[BLT] Setting up mod '%s'", self:GetName()))

	-- Check dependencies are installed for this mod
	if not self:AreDependenciesInstalled() then
		self._dependency_enabled = self._enabled
		table.insert(self._errors, "blt_mod_missing_dependencies")
		self:RetrieveDependencies()
		self:SetEnabled(false, true)
		return
	end

	-- Hooks data
	self:AddHooks("hooks", BLT.hook_tables.post, BLT.hook_tables.wildcards)
	self:AddHooks("pre_hooks", BLT.hook_tables.pre, BLT.hook_tables.wildcards)

	-- Keybinds
	if BLT.Keybinds then
		for i, keybind_data in ipairs(self.raw_data.keybinds or {}) do
			BLT.Keybinds:register_keybind_json(self, keybind_data)
		end
	end

	-- Persist Scripts
	for i, persist_data in ipairs(self.raw_data.persist_scripts or {}) do
		if persist_data and persist_data.global and persist_data.script_path then
			self:AddPersistScript(persist_data.global, persist_data.script_path)
		end
	end

	-- Setup BLTSuperMod (Load assets)
	if self.supermod then
		self.supermod:Setup()
	end

	-- Load native modules
	for i, module_data in ipairs(self.raw_data.native_modules or {}) do
		self:LoadNativeModule(module_data)
	end

	-- Run entry scripts
	for i, script_data in ipairs(self.raw_data.entry_scripts or {}) do
		self:RunEntryScript(script_data)
	end
end

function BLTMod:AddHooks(data_key, destination, wildcards_destination)
	for i, hook_data in ipairs(self.raw_data[data_key] or {}) do
		local hook_id = hook_data.hook_id and hook_data.hook_id:lower()
		local script = hook_data.script_path

		self:AddHook(data_key, hook_id, script, destination, wildcards_destination)
	end
end

function BLTMod:AddHook(data_key, hook_id, script, destination, wildcards_destination)
	if not hook_id or not script or not self:IsEnabled() then
		return
	end

	local data = {
		mod = self,
		script = script
	}

	if hook_id ~= "*" then
		destination[hook_id] = destination[hook_id] or {}
		table.insert(destination[hook_id], data)
	else
		table.insert(wildcards_destination, data)
	end
end

function BLTMod:AddPersistScript(global, file)
	self._persists = self._persists or {}
	table.insert(self._persists, {
		global = global,
		file = file
	})
end

function BLTMod:LoadNativeModule(module_data)
	if not self:IsEnabled() then
		return
	end

	if module_data.loading_vector == "preload" then
		return -- Uses Wren
	end

	if not blt.load_native or not blt.blt_info then
		BLT:Log(LogLevel.ERROR, string.format("[BLT] Cannot load native module for '%s' (functionality missing)", self:GetName()))
		return
	end

	if blt.blt_info().platform ~= module_data.platform then
		BLT:Log(LogLevel.INFO, string.format("[BLT] Incorrect platform for native module for '%s' (%s)", self:GetName(), tostring(module_data.platform)))
		return
	end

	BLT:Log(LogLevel.INFO, string.format("[BLT] Loading native module for '%s'", self:GetName()))
	blt.load_native(self:GetPath() .. module_data.filename)
end

function BLTMod:RunEntryScript(script_data)
	if not self:IsEnabled() then
		return
	end

	BLT:RunHookFile(script_data.script_path, {
		mod = self,
		script = script_data.script_path
	})
end

function BLTMod:GetHooks()
	return table.collect(self.raw_data.hooks or {}, function(v)
		return v.hook_id
	end)
end

function BLTMod:GetPreHooks()
	return table.collect(self.raw_data.pre_hooks or {}, function(v)
		return v.hook_id
	end)
end

function BLTMod:GetPersistScripts()
	return self._persists or {}
end

function BLTMod:GetEntryScripts()
	return table.collect(self.raw_data.entry_scripts or {}, function(v)
		return v.script_path
	end)
end

function BLTMod:GetNativeModules()
	return table.collect(self.raw_data.native_modules or {}, function(v)
		return v.filename
	end)
end

function BLTMod:Errors()
	if #self._errors > 0 then
		return self._errors
	else
		return false
	end
end

function BLTMod:LastError()
	local n = #self._errors
	if n > 0 then
		return self._errors[n]
	else
		return false
	end
end

function BLTMod:IsOutdated()
	return self._outdated
end

function BLTMod:IsEnabled()
	return self.enabled
end

function BLTMod:WasEnabledAtStart()
	return self._enabled
end

function BLTMod:SetEnabled(enable, force)
	self.enabled = self:IsUndisablable() or enable
	if force then
		self._enabled = self.enabled
	end
end

function BLTMod:GetPath()
	return self.path
end

function BLTMod:GetDir()
	-- Strip mod folder name from path
	local dir = self:GetPath():gsub("[^/\\]+[/\\]$", "")
	return dir
end

---@deprecated
function BLTMod:GetJsonData()
	BLT:DeprecationWarning("BLTMod.GetJsonData")
	return self.json_data
end

function BLTMod:GetId()
	return self.id
end

function BLTMod:GetName()
	return self.name
end

function BLTMod:GetDescription()
	return self.desc
end

function BLTMod:GetVersion()
	return self.version
end

function BLTMod:GetBLTVersion()
	return self.blt_version
end

function BLTMod:GetAuthor()
	return self.author
end

function BLTMod:GetContact()
	return self.contact
end

function BLTMod:GetPriority()
	return self.priority
end

function BLTMod:GetColor()
	if not self.color then
		return tweak_data.screen_colors.button_stage_3
	end

	-- Delay evaluation of color until first call
	if type(self.color) == "string" then
		local r, g, b = self.color:match("([.0-9]+)%s+([.0-9]+)%s+([.0-9]+)")
		r = tonumber(r) or 0
		g = tonumber(g) or 0
		b = tonumber(b) or 0
		if r > 1 or g > 1 or b > 1 then
			r = r / 255
			g = g / 255
			b = b / 255
		end
		self.color = Color(r, g, b)
	end

	return self.color
end

function BLTMod:HasModImage()
	return self.image_path ~= nil
end

function BLTMod:GetModImagePath()
	return self:GetPath() .. tostring(self.image_path)
end

function BLTMod:GetModImage()
	if self.mod_image_id then
		return self.mod_image_id
	end

	if not self:HasModImage() or not DB or not DB.create_entry then
		return nil
	end

	-- Check if the file exists on disk and generate if it does
	if file.FileExists(Application:nice_path(self:GetModImagePath())) then
		local type_texture_id = Idstring("texture")
		local path = self:GetModImagePath()
		local texture_id = Idstring(path)

		DB:create_entry(type_texture_id, texture_id, path)

		self.mod_image_id = texture_id

		return texture_id
	else
		BLT:Log(LogLevel.WARN, string.format("Mod image '%s' does not exist", tostring(self:GetModImagePath())))
		return nil
	end
end

function BLTMod:HasUpdates()
	return table.size(self:GetUpdates()) > 0
end

function BLTMod:GetUpdates()
	return self.updates or {}
end

function BLTMod:GetUpdate(id)
	for _, update in ipairs(self:GetUpdates()) do
		if update:GetId() == id then
			return update
		end
	end
end

function BLTMod:HasLegacyUpdate(id)
	return self._legacy_updates[id]
end

function BLTMod:AreUpdatesEnabled()
	for _, update in ipairs(self:GetUpdates()) do
		if not update:IsEnabled() then
			return false
		end
	end
	return true
end

function BLTMod:SetUpdatesEnabled(enable)
	for _, update in ipairs(self:GetUpdates()) do
		update:SetEnabled(enable)
	end
end

function BLTMod:CheckForUpdates(clbk)
	self._update_cache = self._update_cache or {}
	self._update_cache.clbk = clbk

	for _, update in ipairs(self:GetUpdates()) do
		update:CheckForUpdates(callback(self, self, "clbk_check_for_updates"))
	end
end

function BLTMod:IsCheckingForUpdates()
	for _, update in ipairs(self.updates) do
		if update:IsCheckingForUpdates() then
			return true
		end
	end
	return false
end

function BLTMod:GetUpdateError()
	for _, update in ipairs(self:GetUpdates()) do
		if update:GetError() then
			return update:GetError(), update
		end
	end
	return false
end

function BLTMod:clbk_check_for_updates(update, required, reason)
	self._update_cache = self._update_cache or {}
	self._update_cache[update:GetId()] = {
		requires_update = required,
		reason = reason,
		update = update
	}

	if self._update_cache.clbk and not self:IsCheckingForUpdates() then
		local clbk = self._update_cache.clbk
		self._update_cache.clbk = nil
		clbk(self._update_cache)
	end
end

function BLTMod:IsSafeModeEnabled()
	return self.safe_mode
end

function BLTMod:SetSafeModeEnabled(enabled)
	if enabled == nil then
		enabled = true
	end
	if self:DisableSafeMode() then
		enabled = false
	end
	self.safe_mode = enabled
end

function BLTMod:DisableSafeMode()
	if self:IsUndisablable() then
		return true
	end
	return self.disable_safe_mode
end

function BLTMod:IsUndisablable()
	return self.id == "base" or self.undisablable or false
end

function BLTMod:HasDependencies()
	return next(self.dependencies) and true or false
end

function BLTMod:GetDependencies()
	return self.dependencies or {}
end

function BLTMod:GetMissingDependencies()
	return self.missing_dependencies or {}
end

function BLTMod:GetDisabledDependencies()
	return self.disabled_dependencies or {}
end

function BLTMod:AreDependenciesInstalled()
	local installed = true
	self.missing_dependencies = {}
	self.disabled_dependencies = {}

	-- Iterate all mods and updates to find dependencies, store any that are missing
	for id, data in pairs(self:GetDependencies()) do
		local found = false
		for _, mod in ipairs(BLT.Mods:Mods()) do
			if mod:GetName() == id then
				found = true
			elseif mod:HasLegacyUpdate(id) then
				found = true
			else
				for _, update in ipairs(mod:GetUpdates()) do
					if update:GetId() == id then
						found = true
						break
					end
				end
			end

			if found then
				if not mod:IsEnabled() then
					installed = false
					table.insert(self.disabled_dependencies, mod)
					table.insert(self._errors, "blt_mod_dependency_disabled")
				end
				break
			end
		end

		if not found then
			installed = false
			local download_data = type(data) == "table" and data or { download_url = data }
			local new_dependency, valid = BLTModDependency:new(self, id, download_data)
			if valid then
				table.insert(self.missing_dependencies, new_dependency)
			else
				BLT:Log(LogLevel.ERROR, string.format("Invalid dependency '%s' for mod '%s'", id, self:GetName()))
			end
		end
	end

	return installed
end

function BLTMod:RetrieveDependencies()
	for _, dependency in ipairs(self:GetMissingDependencies()) do
		dependency:Retrieve(function(dependency, exists_on_server)
			self:clbk_retrieve_dependency(dependency, exists_on_server)
		end)
	end
end

function BLTMod:clbk_retrieve_dependency(dependency, exists_on_server)
	-- Register the dependency as a download
	if exists_on_server then
		BLT.Downloads:add_pending_download(dependency)
	end
end

function BLTMod:GetDeveloperInfo()
	local str = ""
	local append = function(...)
		for i, s in ipairs({ ... }) do
			str = str .. (i > 1 and " " or "") .. tostring(s)
		end
		str = str .. "\n"
	end

	local hooks = self.raw_data.hooks or {}
	local prehooks = self.raw_data.pre_hooks or {}
	local persists = self.raw_data.persist_scripts or {}
	local entries = self.raw_data.entry_scripts or {}
	local modules = self.raw_data.native_modules or {}

	append("Path:", self:GetPath())
	append("Load Priority:", self:GetPriority())
	append("Version:", self:GetVersion())
	append("BLT-Version:", self:GetBLTVersion())
	append("Disablable:", not self:IsUndisablable())

	if table.size(hooks) < 1 then
		append("No Hooks")
	else
		append("Hooks:")
		for _, hook in ipairs(hooks) do
			append("   ", hook.hook_id, "->", hook.script_path)
		end
	end

	if table.size(prehooks) < 1 then
		append("No Pre-Hooks")
	else
		append("Pre-Hooks:")
		for _, hook in ipairs(prehooks) do
			append("   ", hook.hook_id, "->", hook.script_path)
		end
	end

	if table.size(persists) < 1 then
		append("No Persist Scripts")
	else
		append("Persist Scripts:")
		for _, script in ipairs(persists) do
			append("   ", script.global, "->", script.script_path)
		end
	end

	if table.size(entries) < 1 then
		append("No Entry Scripts")
	else
		append("Entry Scripts:")
		for _, script in ipairs(entries) do
			append("   ", script.script_path)
		end
	end

	if table.size(modules) < 1 then
		append("No Native Modules")
	else
		append("Native Modules:")
		for _, module in ipairs(modules) do
			append("   ", module.platform, "->", module.filename)
		end
	end

	return str
end

function BLTMod:GetSuperMod()
	return self.supermod
end

function BLTMod:IsLibrary()
	return self.library
end

function BLTMod:__tostring()
	return string.format("[BLTMod %s (%s)]", self:GetName(), self:GetId())
end
