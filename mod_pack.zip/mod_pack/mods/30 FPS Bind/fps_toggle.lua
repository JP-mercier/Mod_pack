FpsToggle = FpsToggle or {
    original = managers.user:get_setting("fps_cap"),
    enabled = false
}

FpsToggle.enabled = not FpsToggle.enabled

local new_cap = FpsToggle.enabled and 30 or FpsToggle.original

managers.user:set_setting("fps_cap", new_cap)