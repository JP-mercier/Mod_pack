-- Adds a Recent tab to the Social Hub, after Friends / Invites / Blocked.
--
-- Rows are the game's own SocialHubUserItem, so the buttons (Invite, Add, Block) and what they do
-- are the Social Hub's: SocialHubManager:invite_user_to_lobby sends a crossplay invite that shows
-- up in the other player's game, friend or not. A Forget button removes the row from our list.
--
-- A row needs its player in the Social Hub's user cache. Recorded players are put there from our
-- list, then refreshed with DistributionMatchmaking:search_users_from_id, the lookup the Friends
-- tab uses for crossplay friends.

-- May load before core.lua, which fills in the same table
RecentPlayers = RecentPlayers or {}
local RP = RecentPlayers

-- Rows -------------------------------------------------------------------------------------------
-- The game's row hides the time text on hover only while you are in a lobby, and draws unhovered
-- buttons at half opacity, so our longer "11 MIN AGO | HEIST" text and the buttons overlapped.
-- This row always hides the text on hover and gives each button a solid backing and a gap.

SocialHubRecentUserItem = SocialHubRecentUserItem or class(SocialHubUserItem)

local BUTTON_GAP = 6
local BUTTON_PADDING = 12
local BUTTON_BACKING = Color(0.85, 0.05, 0.07, 0.1) -- alpha first
local BUTTON_TEXT = tweak_data.screen_colors.button_stage_2
local BUTTON_TEXT_SELECTED = Color.white

function SocialHubRecentUserItem:setup_panel()
	SocialHubRecentUserItem.super.setup_panel(self)

	local right_x = alive(self._buttons_panel) and self._buttons_panel:right() - self.type_config.margin

	-- Up to six buttons (Join, Invite, Message, Add, Block, Forget): the small menu font keeps them
	-- clear of the name on most rows.
	for _, button in ipairs(self._buttons or {}) do
		local text = button:child("text")

		text:set_font(Idstring(tweak_data.menu.pd2_small_font))
		text:set_font_size(tweak_data.menu.pd2_small_font_size)
		ExtendedPanel.make_fine_text(text)
		button:rect({
			name = "backing",
			layer = 99,
			color = BUTTON_BACKING
		})
		button:set_w(text:w() + BUTTON_PADDING * 2)
		text:set_center_x(button:w() / 2)
		text:set_center_y(button:h() / 2)
		button:child("bg"):set_w(button:w())
		button:child("backing"):set_w(button:w())
		button:set_right(right_x)

		right_x = button:left() - BUTTON_GAP
	end
end

function SocialHubRecentUserItem:set_item_selected(selected_index)
	self._selected_index = selected_index

	for index, button in ipairs(self._buttons or {}) do
		local selected = index == selected_index

		button:child("bg"):set_visible(selected)
		button:child("text"):set_color(selected and BUTTON_TEXT_SELECTED or BUTTON_TEXT)
	end
end

function SocialHubRecentUserItem:_selected_changed(state)
	SocialHubRecentUserItem.super._selected_changed(self, state)

	if alive(self._right_side_panel) then
		self._right_side_panel:set_visible(not state)
	end
end

SocialHubRecentTab = SocialHubRecentTab or class(SocialHubTab)

function SocialHubRecentTab:init(parent_panel, ws)
	SocialHubRecentTab.super.init(self, parent_panel)

	self._parent_panel = parent_panel

	-- Message box, the game's own text field (the one on the Invites tab). It holds 32 characters,
	-- which is also the longest host name Crime.net shows.
	self._msgbox = SearchBoxGuiObject:new(parent_panel, ws, RP.draft_message, {
		w = 420
	})

	self._msgbox.panel:set_center_x(parent_panel:w() / 2)
	self._msgbox.placeholder_text:set_text("TYPE A MESSAGE, THEN MESSAGE ON A PLAYER")
	self._msgbox.placeholder_text:set_font(Idstring(tweak_data.menu.pd2_small_font))
	self._msgbox.placeholder_text:set_font_size(tweak_data.menu.pd2_small_font_size)
	self._msgbox:register_disconnect_callback(function(text)
		RP.draft_message = text
	end)

	-- Status line: how messages work, or the current lobby name with a click to restore it
	self._status = parent_panel:text({
		layer = 100,
		align = "center",
		font = tweak_data.menu.pd2_small_font,
		font_size = tweak_data.menu.pd2_small_font_size,
		text = "",
		y = self._msgbox.panel:bottom() + 4,
		h = tweak_data.menu.pd2_small_font_size + 2
	})

	self._scroll_panel = parent_panel:panel({
		y = self._status:bottom() + 6
	})

	self._scroll_panel:set_h(parent_panel:h() - self._scroll_panel:y())

	self.scroll = ScrollItemList:new(self._scroll_panel, {
		input_focus = true,
		padding = 0,
		scrollbar_padding = 10
	}, {
		layer = 100
	})

	self:setup_panel()
	self:fetch_users()
end

function SocialHubRecentTab:valid()
	return alive(self._parent_panel)
end

function SocialHubRecentTab:message_text()
	return self._msgbox and alive(self._msgbox.text) and self._msgbox.text:text() or ""
end

function SocialHubRecentTab:update_status()
	if not alive(self._status) then
		return
	end

	if RP.lobby_message then
		self._status:set_text("LOBBY NAME: \"" .. RP.lobby_message .. "\"  -  CLICK TO RESTORE")
		self._status:set_color(tweak_data.screen_colors.button_stage_2)
	else
		self._status:set_text("SENT AS YOUR LOBBY NAME WITH AN INVITE (HOST A LOBBY FIRST)")
		self._status:set_color(tweak_data.screen_colors.text:with_alpha(0.6))
	end
end

function SocialHubRecentTab:status_clickable(x, y)
	return RP.lobby_message and alive(self._status) and self._status:inside(x, y)
end

function SocialHubRecentTab:close_input()
	if self._msgbox and self._msgbox:input_focus() then
		self._msgbox:disconnect_search_input()
	end
end

function SocialHubRecentTab:shown_players()
	local list = RP:sorted()
	local shown = {}

	for i = 1, math.min(#list, RP.MAX_SHOWN) do
		table.insert(shown, list[i])
	end

	return shown
end

function SocialHubRecentTab:setup_panel()
	for _, p in ipairs(self:shown_players()) do
		if not managers.socialhub:user_exists(p.id) then
			managers.socialhub:add_cached_user(p.id, {
				display_name = p.name,
				id = p.id,
				account_id = p.account_id,
				account_type = Idstring(p.account or "STEAM")
			})
		end

		local buttons = managers.socialhub:get_actions_for_user(self, "on_user_item_pressed", p.id) or {}
		local id = p.id
		local session = managers.network:session()
		local with_us = session and session:peer_by_user_id(p.id)

		-- Buttons are laid out right to left: Join ends up rightmost, next to Invite
		if not with_us then
			table.insert(buttons, 1, {
				action = "join",
				text = "JOIN",
				press_callback = function()
					local ok, err = pcall(RP.join, RP, p)

					if not ok then
						RP:log("Join " .. tostring(p.name) .. ": " .. tostring(err))
						RP:popup("Join " .. p.name, "Something went wrong looking for their lobby. Details are in the SuperBLT log.")
					end
				end
			})
		end

		-- Message goes right after Invite (or Join when there is no Invite)
		local message_at = buttons[1] and buttons[1].action == "join" and 2 or 1

		for index, button in ipairs(buttons) do
			if button.action == "invite" or button.action == "invite_sent" then
				message_at = index + 1
			end
		end

		if not with_us then
			table.insert(buttons, math.min(message_at, #buttons + 1), {
				action = "message",
				text = "MESSAGE",
				press_callback = function()
					local ok, err = pcall(RP.send_message, RP, p, self:message_text())

					if not ok then
						RP:log("Message " .. tostring(p.name) .. ": " .. tostring(err))
						RP:popup("Message " .. p.name, "Something went wrong sending the message. Details are in the SuperBLT log.")
					end
				end
			})
		end

		table.insert(buttons, {
			action = "forget",
			text = "FORGET",
			press_callback = function()
				RP:forget(id)
				self:reset_tab()
			end
		})

		local item = SocialHubRecentUserItem:new(self.scroll:canvas(), {
			right_display = "status",
			id = p.id,
			buttons = buttons
		})

		-- Show when you last played together instead of an online status, which is only known for friends
		if alive(item._state_text) then
			local text = RP.ago(p.last_seen)

			if p.heist then
				text = text .. "  |  " .. p.heist
			end

			item._state_text:set_text(utf8.to_upper(text))
			ExtendedPanel.make_fine_text(item._state_text)
			item._state_text:set_center_y(item._right_side_panel:center_y())
			item._state_text:set_right(item._right_side_panel:right() - item.type_config.margin)
		end

		self.scroll:add_item(item)
	end

	self.scroll:select_index(1)
	self:update_status()
end

function SocialHubRecentTab:fetch_users()
	local ids = {}

	for _, p in ipairs(self:shown_players()) do
		table.insert(ids, p.id)
	end

	if #ids == 0 then
		return
	end

	DistributionMatchmaking:search_users_from_id(ids, function(users)
		local ok, err = pcall(self.on_users_fetched, self, users)

		if not ok then
			RP:log("Recent tab user lookup: " .. tostring(err))
		end
	end)
end

function SocialHubRecentTab:on_users_fetched(users)
	local found = 0

	for _, user in pairs(users or {}) do
		-- The crossplay lookup reports every user as EPIC; keep the platform we saw them on.
		local p = RP.players and RP.players[tostring(user:id())]

		managers.socialhub:add_cached_user(user:id(), {
			display_name = user:username(),
			id = user:id(),
			account_id = p and p.account_id or user:account_id(),
			account_type = p and p.account and Idstring(p.account) or user:type()
		})

		found = found + 1
	end

	RP:log("Recent tab: crossplay lookup found " .. found .. " players")

	if found > 0 and self:valid() then
		self:reset_tab()
	end
end

function SocialHubRecentTab:reset_tab()
	if not self:valid() then
		return
	end

	for _, item in ipairs(self.scroll:all_items()) do
		item:remove_self()
	end

	self.scroll:clear()
	self:setup_panel()
end

function SocialHubRecentTab:on_selected()
	self:update_status()
end

function SocialHubRecentTab:mouse_moved(button, x, y)
	local used, pointer = self.scroll:mouse_moved(button, x, y)

	if used then
		return used, pointer
	end

	used, pointer = self._msgbox:mouse_moved(button, x, y)

	if used then
		return used, pointer
	end

	if self:status_clickable(x, y) then
		return true, "link"
	end
end

function SocialHubRecentTab:mouse_pressed(button, x, y)
	-- Same order as the Invites tab: rows first, then the text box (which also unfocuses on outside clicks)
	self.scroll:mouse_pressed(button, x, y)

	if self._msgbox:mouse_pressed(button, x, y) then
		return
	end

	if button == Idstring("0") and self:status_clickable(x, y) then
		RP:clear_lobby_message("restored from the Recent tab")
	end
end

function SocialHubRecentTab:mouse_released(o, button, x, y)
	return self.scroll:mouse_released(o, button, x, y)
end

function SocialHubRecentTab:mouse_wheel_up(x, y)
	return self.scroll:mouse_wheel_up(x, y)
end

function SocialHubRecentTab:mouse_wheel_down(x, y)
	return self.scroll:mouse_wheel_down(x, y)
end

function SocialHubRecentTab:move_up()
	self.scroll:move_up()
end

function SocialHubRecentTab:move_down()
	self.scroll:move_down()
end

function SocialHubRecentTab:move_left()
	local item = self.scroll:selected_item()

	if item and item.move_left then
		item:move_left()
	end
end

function SocialHubRecentTab:move_right()
	local item = self.scroll:selected_item()

	if item and item.move_right then
		item:move_right()
	end
end

function SocialHubRecentTab:confirm_pressed()
	if self._msgbox:input_focus() then
		self._msgbox:disconnect_search_input()

		return
	end

	local item = self.scroll:selected_item()

	if item and item.confirm_pressed then
		item:confirm_pressed()
	end
end

-- Hub wiring ---------------------------------------------------------------------------------

function SocialHubGui:recent_players_select_tab()
	if self._recent_players_index then
		self:on_tab_item_pressed(self._recent_players_index)
	end
end

Hooks:PostHook(SocialHubGui, "setup", "RecentPlayers_socialhub_setup", function(self)
	local ok, err = pcall(function()
		local index = #self._categories_runtime + 1
		local panel = self._main_panel:panel({
			visible = false,
			y = 50,
			h = self._main_panel:h() - 50
		})

		table.insert(self._content_panel_list, panel)

		local last_tab = self._categories_runtime[index - 1].tab_item
		local tab_item = TabItem:new(self._tab_panel, {
			layer = 100,
			x = last_tab:bounds().right + 5
		}, {
			name_id = "recent_players_tab",
			callback = callback(self, self, "on_tab_item_pressed", index)
		})

		self._categories_runtime[index] = {
			name_id = "recent_players_tab",
			components = {},
			tab_item = tab_item,
			tab = SocialHubRecentTab:new(panel, self._ws)
		}
		self._recent_players_index = index

		-- Opened from our "Recent Players" menu button
		if RP.open_recent_tab then
			RP.open_recent_tab = nil
			self:recent_players_select_tab()
		end
	end)

	if not ok then
		RP:log("Couldn't add the Recent tab: " .. tostring(err))
	end
end)

-- Invite / Add / Block reset the Friends and Invites tabs; refresh ours too so "Invite sent" shows.
Hooks:PostHook(SocialHubGui, "reset_tab_by_name", "RecentPlayers_socialhub_reset", function(self, tab_name)
	if tab_name == "friend" and self._recent_players_index then
		pcall(self.reset_tab_by_index, self, self._recent_players_index)
	end
end)

-- Closing the hub while typing in the message box would leave the keyboard hooked to a removed panel
Hooks:PreHook(SocialHubGui, "close", "RecentPlayers_socialhub_close", function(self)
	local entry = self._recent_players_index and self._categories_runtime and self._categories_runtime[self._recent_players_index]

	if entry and entry.tab and entry.tab.close_input then
		pcall(entry.tab.close_input, entry.tab)
	end
end)
