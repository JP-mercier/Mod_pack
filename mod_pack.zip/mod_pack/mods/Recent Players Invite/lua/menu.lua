-- Adds "Recent Players" under "Social Hub" in every menu that has one (the Escape menu in a heist,
-- the lobby menu, the main menu). It opens the same Social Hub page, on the Recent tab.
-- The game's menus come from XML we can't see, so the Social Hub button is found by name or
-- next_node containing "social" (but not "option": the Options page has a Social Hub settings button).

RecentPlayers = RecentPlayers or {}
local RP = RecentPlayers

local ITEM_NAME = "recent_players_invite_btn"

Hooks:Add("LocalizationManagerPostInit", "RecentPlayers_loc", function(loc)
	loc:add_localized_strings({
		recent_players_menu = "Recent Players",
		recent_players_menu_desc = "Players you played with recently. Invite them to your lobby.",
		recent_players_tab = "Recent"
	})
end)

-- The menu runs an item's callback and opens its next_node; whichever comes first, end up on our tab.
function MenuCallbackHandler:recent_players_open()
	RP.open_recent_tab = true

	local gui = managers.menu_component and managers.menu_component._social_hub_gui

	if gui and gui:socialhub_valid() and gui.recent_players_select_tab then
		RP.open_recent_tab = nil
		gui:recent_players_select_tab()
	end
end

-- Plain buttons only: the Social Hub options page has "socialhub_*" toggles and choices too.
local function social_hub_node(item)
	if item.TYPE ~= "item" then
		return nil
	end

	local params = item:parameters() or {}
	local name = tostring(params.name or ""):lower()
	local next_node = params.next_node and tostring(params.next_node) or nil
	local text = name .. " " .. (next_node or ""):lower()

	if not next_node or not text:find("social", 1, true) or text:find("option", 1, true) then
		return nil
	end

	return next_node
end

local function add_to(node, node_name)
	local position, next_node

	for index, item in ipairs(node._items or {}) do
		if item:name() == ITEM_NAME then
			return
		end

		if not position then
			next_node = social_hub_node(item)
			position = next_node and index + 1
		end
	end

	if not position then
		return
	end

	local item = node:create_item({ type = "CoreMenuItem.Item" }, {
		name = ITEM_NAME,
		text_id = "recent_players_menu",
		help_id = "recent_players_menu_desc",
		callback = "recent_players_open",
		next_node = next_node
	})

	item.dirty_callback = callback(node, node, "item_dirty")

	if node.callback_handler then
		item:set_callback_handler(node.callback_handler)
	end

	table.insert(node._items, position, item)

	log("[Recent Players] Added the menu button to node " .. tostring(node_name) .. " (opens " .. tostring(next_node) .. ")")
end

Hooks:Add("MenuManagerBuildCustomMenus", "RecentPlayers_menu_button", function(menu_manager, nodes)
	for node_name, node in pairs(nodes) do
		local ok, err = pcall(add_to, node, node_name)

		if not ok then
			log("[Recent Players] Menu button on node " .. tostring(node_name) .. ": " .. tostring(err))
		end
	end
end)
