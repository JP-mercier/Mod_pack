-- Message: send a short text along with a lobby invite.
--
-- There is no way to message a player who is not your Steam friend. But when they get an invite, their
-- Social Hub fetches your lobby and lists it under Invites by its owner_name lobby attribute
-- (SocialHubLobbyItem). While you host, that attribute is yours to set. So: rename your lobby to the
-- message, then invite them. The invite pop-up itself still shows your real account name.
--
-- The name stays until someone joins, you restore it, you leave, or MESSAGE_SECONDS pass.
-- A public lobby shows the message as its name on Crime.net meanwhile, so host a private one.

RecentPlayers = RecentPlayers or {}
local RP = RecentPlayers

RP.MESSAGE_SECONDS = 600
RP.MESSAGE_INVITE_DELAY = 2 -- lets the lobby service publish the new name before they fetch it

-- Runs on every require of the matchmaking file, which redefines set_attributes. SuperBLT's PostHook
-- skips an id it already has, so the hook would be lost after a reload; wrap by hand each time instead.
RP._wrapped = RP._wrapped or setmetatable({}, { __mode = "k" })

if not RP._wrapped[NetworkMatchMakingSTEAM.set_attributes] then
	local orig_set_attributes = NetworkMatchMakingSTEAM.set_attributes

	function NetworkMatchMakingSTEAM:set_attributes(...)
		local r = { orig_set_attributes(self, ...) }

		-- The game rebuilds every attribute (owner_name included) on each lobby change; put ours back.
		if RP.lobby_message then
			pcall(RP._apply_lobby_name, RP)
		end

		return unpack(r)
	end

	RP._wrapped[NetworkMatchMakingSTEAM.set_attributes] = true
end

function RP:hosting_lobby()
	local session = managers.network and managers.network:session()
	local mm = managers.network and managers.network.matchmake

	return session and session:is_host() and mm and mm.lobby_handler and mm._lobby_attributes and true or false
end

-- Sends the game's own attributes, with owner_name replaced while a message is set
function RP:_apply_lobby_name()
	local mm = managers.network.matchmake
	local attributes = mm and mm._lobby_attributes

	if not attributes or not mm.lobby_handler then
		return false
	end

	local data = {}

	for k, v in pairs(attributes) do
		data[k] = v
	end

	if self.lobby_message then
		data.owner_name = self.lobby_message
	end

	mm.lobby_handler:set_lobby_data(data)

	return true
end

function RP:_refresh_tab()
	pcall(function()
		managers.menu_component:social_hub_gui_reset_tab_by_name("friend")
	end)
end

function RP:send_message(p, text)
	text = tostring(text or ""):match("^%s*(.-)%s*$")

	if text == "" then
		self:popup("Message " .. p.name, "Type your message in the box at the top of this tab first (32 characters max), then press Message.")

		return
	end

	if not self:hosting_lobby() then
		self:popup("Message " .. p.name, "A message is sent as your lobby's name, together with an invite, so you need to host a lobby first.\n\nHost any contract and set it to Private, so nobody else sees the message on Crime.net. Then press Message again.")

		return
	end

	self.lobby_message = text

	if not self:_apply_lobby_name() then
		self.lobby_message = nil
		self:popup("Message " .. p.name, "Couldn't rename your lobby.")

		return
	end

	self:log("Lobby renamed to \"" .. text .. "\" for " .. tostring(p.name))

	DelayedCalls:Add("RecentPlayers_message_timeout", self.MESSAGE_SECONDS, function()
		RP:clear_lobby_message("timed out")
	end)
	DelayedCalls:Add("RecentPlayers_message_invite_" .. p.id, self.MESSAGE_INVITE_DELAY, function()
		if RP.lobby_message ~= text or not RP:hosting_lobby() then
			return
		end

		local ok, err = pcall(function()
			managers.socialhub:invite_user_to_lobby(p.id)
		end)

		if ok then
			RP:log("Invited " .. tostring(p.name) .. " with the message")
		else
			RP:log("Message invite to " .. tostring(p.name) .. " failed: " .. tostring(err))
			RP:popup("Message " .. p.name, "The invite didn't go out: " .. tostring(err))
		end

		RP:_refresh_tab()
	end)

	self:popup("Message " .. p.name, p.name .. " gets an invite from you in a couple of seconds. In their Social Hub, under Invites, your lobby is listed as:\n\n\"" .. text .. "\"\n\nThe invite pop-up itself shows your normal name, so they have to open the Social Hub to read it.\n\nYour lobby keeps this name until someone joins, you click the line under the message box, or " .. math.floor(self.MESSAGE_SECONDS / 60) .. " minutes pass.")
	self:_refresh_tab()
end

-- applied: false when the lobby is going away, so there is nothing to send
function RP:clear_lobby_message(reason, applied)
	if not self.lobby_message then
		return
	end

	self.lobby_message = nil

	DelayedCalls:Remove("RecentPlayers_message_timeout")

	if applied ~= false then
		pcall(self._apply_lobby_name, self)
	end

	self:log("Lobby name restored (" .. tostring(reason) .. ")")
	self:_refresh_tab()
end
