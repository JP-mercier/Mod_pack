-- Recent Players Invite
-- Remembers every player you share a session with, as host or client, across game restarts.
-- lua/socialhub.lua shows them in a Recent tab of the Social Hub, which invites them the way its
-- other tabs do. Nothing is sent to anyone unless you press Invite there.
--
-- Peers are keyed by peer:user_id(), the 32-character crossplay (EOS) ID the Social Hub works with.
-- account_id is the Steam64 ID for Steam players.

RecentPlayers = RecentPlayers or {}
local RP = RecentPlayers

RP.MAX_SAVED = 20 -- oldest players are forgotten past this
RP.MAX_SHOWN = 20 -- rows in the Recent tab, newest first
RP.SAVE_FILE = SavePath .. "recent_players.json"

function RP:log(msg)
	log("[Recent Players] " .. tostring(msg))
end

-- Storage ------------------------------------------------------------------------------------

function RP:load()
	if self.players then
		return
	end

	-- Parsing the file takes ~0.3 s at 250 players. Global survives the Lua reload between heists,
	-- so it is parsed once per game launch instead of freezing the first join or leave of every heist.
	if Global.recent_players then
		self.players = Global.recent_players

		return
	end

	self.players = {}
	Global.recent_players = self.players

	local f = io.open(self.SAVE_FILE, "r")

	if not f then
		return
	end

	local text = f:read("*all")

	f:close()

	local ok, data = pcall(json.decode, text)

	if ok and type(data) == "table" and type(data.players) == "table" then
		for id, p in pairs(data.players) do
			if type(p) == "table" and type(p.name) == "string" then
				p.id = tostring(id)
				p.invited_t = nil
				self.players[p.id] = p
			end
		end
	else
		-- Keep the unreadable file instead of overwriting it on the next save
		os.rename(self.SAVE_FILE, self.SAVE_FILE .. ".bad")
		self:log("Couldn't read " .. self.SAVE_FILE .. ", moved it to .bad and started a new list")
	end
end

function RP:sorted()
	self:load()

	local list = {}

	for _, p in pairs(self.players) do
		table.insert(list, p)
	end

	table.sort(list, function(a, b)
		return (a.last_seen or 0) > (b.last_seen or 0)
	end)

	return list
end

function RP:save()
	local list = self:sorted()

	for i = self.MAX_SAVED + 1, #list do
		self.players[list[i].id] = nil
	end

	local ok, text = pcall(json.encode, { players = self.players })

	if not ok then
		self:log("Couldn't encode the list: " .. tostring(text))

		return
	end

	local f = io.open(self.SAVE_FILE, "w")

	if not f then
		self:log("Couldn't write " .. self.SAVE_FILE)

		return
	end

	f:write(text)
	f:close()
end

function RP:forget(id)
	self:load()

	self.players[tostring(id)] = nil

	self:save()
end

-- Recording ----------------------------------------------------------------------------------

function RP:_job_name()
	local job_id = managers.job and managers.job:current_job_id()
	local job = job_id and tweak_data.narrative.jobs[job_id]

	return job and job.name_id and managers.localization:text(job.name_id) or nil
end

function RP:_lobby_id()
	local mm = managers.network and managers.network.matchmake
	local handler = mm and mm.lobby_handler

	return handler and handler:id() and tostring(handler:id()) or nil
end

-- joined: true when the player was just added to the session (counts a session, updates heist),
-- false for a later sighting that only refreshes the name and time.
-- hosting: they are the host of the lobby we are in, so the lobby is theirs and can be joined later.
function RP:record(user_id, name, account, account_id, joined, hosting)
	if not user_id or user_id == "" then
		return
	end

	local id = tostring(user_id)

	if id == tostring(managers.network.matchmake:userid()) then
		return
	end

	self:load()

	local now = os.time()
	local p = self.players[id]

	if not p then
		p = { id = id, first_seen = now, sessions = 0 }
		self.players[id] = p
	end

	if name and name ~= "" then
		p.name = name
	end

	p.name = p.name or id
	p.account = account or p.account
	p.account_id = account_id and tostring(account_id) or p.account_id
	p.last_seen = now

	if joined then
		p.sessions = (p.sessions or 0) + 1

		local ok, heist = pcall(self._job_name, self)

		p.heist = ok and heist or p.heist
	end

	if hosting then
		p.lobby = self:_lobby_id() or p.lobby
	end

	self:save()
end

-- Joining ------------------------------------------------------------------------------------
-- A lobby can't be looked up by player in general. In order:
-- 1. Steam friends: Steam reports the lobby they are in now (what Crime.net's friends filter uses).
-- 2. Lobbies Crime.net has listed this session, by host (owner_id is the host's Steam64 ID).
-- 3. The last lobby we saw them host. PAYDAY 2 lobbies close when the host leaves, so if it still
--    exists they are still hosting it, whatever heist it is on now.

function RP:_friend_lobby(p)
	for _, friend in ipairs(Distribution:friends() or {}) do
		local fid = tostring(friend:id())

		if fid == p.account_id or fid == p.id or tostring(friend:account_id()) == p.account_id then
			local lobby = friend:lobby()

			return lobby and lobby:id() or nil
		end
	end

	return nil
end

function RP:_crimenet_lobby(p)
	local browser = managers.network.matchmake.browser

	if not browser or not p.account_id then
		return nil
	end

	for _, lobby in ipairs(browser:lobbies() or {}) do
		if tostring(lobby:key_value("owner_id")) == p.account_id then
			return lobby:id()
		end
	end

	return nil
end

-- cb(lobby_id or nil, how)
function RP:find_lobby(p, cb)
	local ok, lobby_id = pcall(self._friend_lobby, self, p)

	if ok and lobby_id then
		return cb(lobby_id, "Steam friend")
	end

	ok, lobby_id = pcall(self._crimenet_lobby, self, p)

	if ok and lobby_id then
		return cb(lobby_id, "Crime.net")
	end

	if not p.lobby then
		return cb(nil)
	end

	DistributionMatchmaking:lobby_from_id(p.lobby, false, function(lobby, result)
		if lobby and (result == nil or result == "success") then
			cb(lobby:id(), "last lobby they hosted")
		else
			cb(nil)
		end
	end)
end

function RP:popup(title, text)
	QuickMenu:new(title, text, {}, true)
end

function RP:join(p)
	if managers.network:session() then
		self:popup("Join " .. p.name, "Leave your current lobby first, then press Join again.")

		return
	end

	self:find_lobby(p, function(lobby_id, how)
		if not lobby_id then
			RP:popup("Join " .. p.name, "Couldn't find a lobby for " .. p.name .. ".\n\nThe game can only find someone's lobby if they are your Steam friend, host a lobby Crime.net has shown you, or are still hosting the lobby you last played in with them. You can invite them to yours instead.")

			return
		end

		RP:log("Joining " .. tostring(p.name) .. " in lobby " .. tostring(lobby_id) .. " (" .. tostring(how) .. ")")
		managers.network.matchmake:join_server_with_check(lobby_id)
	end)
end

function RP:record_peer(peer, joined)
	self:record(peer:user_id(), peer:name(), peer:account_type_str(), peer:account_id(), joined)
end

function RP.ago(t)
	if not t then
		return ""
	end

	local s = math.max(0, os.time() - t)

	if s < 60 then
		return "just now"
	elseif s < 3600 then
		return math.floor(s / 60) .. " min ago"
	elseif s < 86400 then
		return math.floor(s / 3600) .. " h ago"
	end

	return math.floor(s / 86400) .. " d ago"
end

-- Hooks ----------------------------------------------------------------------------------------

if RequiredScript == "lib/network/base/basenetworksession" then
	-- This file loads behind a loading screen; parse the list now rather than on the first join.
	pcall(RP.load, RP)

	-- Runs for every player except you: the host when you join, others as they are introduced.
	Hooks:PostHook(BaseNetworkSession, "add_peer", "RecentPlayers_add_peer", function(self, name, rpc, in_lobby, loading, synched, id, character, user_id, account_type_str, account_id)
		-- Peer 1 is the host; as a client the lobby we are in is theirs.
		local hosting = id == 1 and not self:is_host()
		local ok, err = pcall(RP.record, RP, user_id, name, account_type_str, account_id, true, hosting)

		if not ok then
			RP:log("add_peer: " .. tostring(err))
		end

		-- Someone joined the lobby we renamed (lua/message.lua): the message did its job
		if RP.lobby_message and self:is_host() and RP.clear_lobby_message then
			pcall(RP.clear_lobby_message, RP, "someone joined")
		end
	end)

	-- Refresh the time (and name) when they leave, so "last seen" is when you stopped playing together.
	Hooks:PreHook(BaseNetworkSession, "remove_peer", "RecentPlayers_remove_peer", function(self, peer)
		if peer then
			pcall(RP.record_peer, RP, peer, false)
		end
	end)

	-- Leaving a lobby or a heist yourself does not remove each peer first.
	Hooks:PreHook(BaseNetworkSession, "destroy", "RecentPlayers_destroy", function(self)
		for _, peer in pairs(self._peers or {}) do
			pcall(RP.record_peer, RP, peer, false)
		end

		if RP.lobby_message and RP.clear_lobby_message then
			pcall(RP.clear_lobby_message, RP, "left the lobby", false)
		end
	end)
end
