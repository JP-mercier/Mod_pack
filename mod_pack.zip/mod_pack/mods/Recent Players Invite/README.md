# Recent Players Invite

SuperBLT mod for PAYDAY 2. Remembers every player you share a lobby or heist with and adds a **Recent** tab to the Social Hub, so you can invite them again.

Only you need the mod. The other player gets a normal Social Hub invite.

## Requirements

- PAYDAY 2
- [SuperBLT](https://superblt.znix.xyz/)

## Installation

Extract to `PAYDAY 2/mods/`.

## Usage

Open the Social Hub and pick the **Recent** tab, or use **Recent Players** right under **Social Hub** in the Escape menu (heist, lobby, main menu), which opens the Social Hub on that tab.

Players are listed newest first, up to 20, with a Steam or Epic icon, when you last played together and the heist:

```
[icon] Name                                   2 H AGO  |  THE BIG BANK
```

Select a row for its buttons:

| Button        | What it does                                                                 |
|---------------|------------------------------------------------------------------------------|
| Join          | Joins the lobby they are in, when it can be found (see below). Not shown for players already with you. |
| Message       | Sends the text from the box at the top of the tab, as your lobby's name, with an invite (see below). |
| Invite        | The Social Hub's invite to your current lobby. Shown only when you are in one. |
| Add / Block   | The Social Hub's own crossplay friend and block lists.                       |
| Forget        | Removes the player from this mod's list.                                     |

## How it works

### Recording

`lua/core.lua` hooks `lib/network/base/basenetworksession`:

| Hook                                   | Effect                                                             |
|----------------------------------------|--------------------------------------------------------------------|
| `BaseNetworkSession:add_peer` (post)   | Adds or updates the player, counts a session, saves the heist name |
| `BaseNetworkSession:remove_peer` (pre) | Updates last seen time and name                                    |
| `BaseNetworkSession:destroy` (pre)     | Same for everyone still there when you leave                       |

Players are keyed by `peer:user_id()`, the 32-character crossplay (EOS) ID the Social Hub uses. The Steam64 ID (`peer:account_id()`) and account type (`STEAM`/`EPIC`) are saved with it.

The list is saved to `PAYDAY 2/mods/saves/recent_players.json`, capped at 20 players (oldest dropped). An unreadable file is renamed to `recent_players.json.bad` instead of being overwritten.

The file is read once per game launch, while the game boots, and kept in `Global.recent_players`. The game reloads all Lua between heists and only `Global` survives. Reading the file on the first join or leave of every heist froze the game: SuperBLT's JSON decoder took about 0.3 s for 250 players. Each join or leave still rewrites the file, which takes a few milliseconds.

### Recent tab

`lua/socialhub.lua` hooks `lib/managers/social_hub/menunodesocialhubgui`. A post-hook on `SocialHubGui:setup` adds a fourth tab after Friends / Invites / Blocked.

Each row is the game's `SocialHubUserItem` with the buttons from `SocialHubManager:get_actions_for_user`, plus Forget. A row needs its player in the Social Hub user cache, so recorded players are added there from the saved list (`SocialHubManager:add_cached_user`). The tab then looks them up with `DistributionMatchmaking:search_users_from_id`, the call the Friends tab uses for crossplay friends, and redraws with the current names.

Invite goes through `SocialHubManager:invite_user_to_lobby`: `DistributionMatchmaking:user_from_id(id):invite(lobby_id)` for anyone who is not a platform friend. The invite shows up in the other player's game, friend or not.

An invite goes to the player, not to a lobby: it reaches them wherever they are and asks them into the lobby you are in now.

### Join

The game has no lookup for "the lobby this player is in", so Join tries, in order:

1. **Steam friends:** the lobby Steam reports for them now (`friend:lobby()`, the same source as Crime.net's friends filter).
2. **Crime.net:** lobbies the Crime.net browser listed this session, matched on the lobby's `owner_id` (the host's Steam64 ID).
3. **Last lobby they hosted:** saved when you joined a lobby they hosted, checked with `DistributionMatchmaking:lobby_from_id`. PAYDAY 2 lobbies close when the host leaves, so if it still exists they are still hosting it, even after changing heists.

The lobby found is joined with `NetworkMatchMakingSTEAM:join_server_with_check`, the same call as clicking a lobby on Crime.net, so the usual checks apply (private lobby, reputation, heist owned, game already started). Join only works when you are not in a lobby; leave first.

### Message

There is no way to message a player who is not your Steam friend. A lobby invite is the one thing that reaches them, and when it arrives their Social Hub lists your lobby under **Invites** by its `owner_name` lobby attribute (`SocialHubLobbyItem`). While you host, that attribute is yours to set.

`lua/message.lua` hooks `lib/network/matchmaking/networkmatchmakingsteam`. **Message**:

1. Needs text in the box (the game's `SearchBoxGuiObject`, 32 characters, the same as Crime.net's host name limit) and a lobby you host.
2. Sends your lobby's attributes again with `owner_name` set to the message (`lobby_handler:set_lobby_data`).
3. After 2 s, so the lobby service has published it, invites the player with `SocialHubManager:invite_user_to_lobby`.

`NetworkMatchMakingSTEAM:set_attributes` rebuilds every attribute on each lobby change, so it is wrapped to put the message back each time. The wrap is applied by hand on every load of the file: SuperBLT's `PostHook` skips an id it already has, so it would be lost if the game reloads the file.

The real name comes back when someone joins, when you click the status line under the box, when you leave the lobby, or after 10 minutes.

The other player sees a normal "invited you" pop-up with your real account name (`sender:username()`, which a mod can't change). They have to open **Social Hub > Invites** to read the message. Host a **private** lobby for this: a public one shows the message as its name on Crime.net meanwhile. Keep the lobby open until they have read it, since the Invites tab re-fetches the lobby when opened.

### Menu button

`lua/menu.lua` hooks `lib/managers/menumanager`. In `MenuManagerBuildCustomMenus` it looks through every menu node for a plain button whose name or `next_node` contains `social` but not `option`. It inserts **Recent Players** after it with the same `next_node`, and sets a flag so the Social Hub opens on the Recent tab. Each node it changes is logged (`Added the menu button to node ...`).

## Settings

At the top of `lua/core.lua`: `MAX_SAVED` (20), `MAX_SHOWN` (20 rows). At the top of `lua/message.lua`: `MESSAGE_SECONDS` (600), `MESSAGE_INVITE_DELAY` (2 s).

## Limitations

- The Social Hub saves its user cache in the game's save file. Rows shown in the Recent tab are added to that cache, like players found with the Invites tab search.
- Online status is not shown: the row shows when you last played together instead.
- The game does not report whether an invite was accepted.
- Players you played with before installing the mod are not in the list.
- Join can't find a non-friend who is a client in someone else's lobby, or who hosts a new lobby that Crime.net hasn't listed for you (private, friends-only, or filtered out). Invite them instead.

## Troubleshooting

Log lines go to the SuperBLT log in `PAYDAY 2/mods/logs/` with the prefix `[Recent Players]`. `Recent tab: crossplay lookup found N players` shows how many saved players the lookup found.
