-- Heat level for any job is always 0 (used by crime.net, contract broker, XP/money calcs)
function JobManager:get_job_heat(job_id)
	return 0
end
-- Heat -> XP multiplier is always neutral
function JobManager:heat_to_experience_multiplier(heat)
	return 1
end
function JobManager:get_job_heat_multipliers(job_id)
	return 1
end
-- Always show the neutral heat color
function JobManager:get_job_heat_color(job_id)
	return tweak_data.screen_colors.heat_standard_color
end
function JobManager:get_heat_color(heat)
	return tweak_data.screen_colors.heat_standard_color
end
function JobManager:current_job_heat_color()
	return tweak_data.screen_colors.heat_standard_color
end
