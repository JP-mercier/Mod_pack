ChatTranslator = ChatTranslator or {}
ChatTranslator.CHAT_TYPE = {
    CHATGUI = 1,
    HUDCHAT = 2
}
ChatTranslator.HUD = {
    DEFAULT = 1,
    WOLFHUD = 2,
    VOIDUI = 3,
    VANILLAHUD = 4,
    AUTO = 5
}
ChatTranslator.default_settings = {
    language = "en",
    keyword = "tl",
    hud = ChatTranslator.HUD.AUTO,
    extend_chat = true,
    mouse_pointer = true,
    -- Translate other players' messages as they arrive. Off unless turned on in the options or with "tl auto".
    auto_translate = false,
    -- Base language codes that auto-translate leaves alone (the translation language is always left alone)
    auto_exclude = {
        fr = true
    }
}

-- Languages most often seen in PAYDAY 2 lobbies, used by "tl help" and the auto-translate skip list
ChatTranslator.HELP_GROUPS = {{
    label = "Americas",
    codes = {"es", "pt"}
}, {
    label = "West/North",
    codes = {"fr", "de", "it", "nl", "sv", "no", "da", "fi"}
}, {
    label = "East",
    codes = {"ru", "uk", "pl", "cs", "sk", "hu", "ro", "bg", "sr", "hr", "lt", "lv", "et"}
}, {
    label = "South",
    codes = {"el", "tr", "ar"}
}, {
    label = "Asia",
    codes = {"ja", "ko", "zh-CN", "zh-TW", "vi", "th", "id", "tl"}
}}

ChatTranslator.EXTRA_LANGUAGES = {
    ["zh-CN"] = "Chinese",
    ["zh-TW"] = "Chinese (Taiwan)"
}

-- Country codes and other spellings people type instead of the language code
ChatTranslator.ALIASES = {
    jp = "ja",
    kr = "ko",
    cn = "zh-CN",
    zh = "zh-CN",
    ["zh-cn"] = "zh-CN",
    ["zh-tw"] = "zh-TW",
    tw = "zh-TW",
    ua = "uk",
    br = "pt",
    cz = "cs",
    gr = "el",
    se = "sv",
    dk = "da",
    ee = "et",
    rs = "sr",
    by = "be",
    vn = "vi",
    ph = "tl",
    fil = "tl",
    il = "he",
    iw = "he",
    ir = "fa",
    gb = "en",
    us = "en",
    mx = "es"
}

-- Words that mark a message as an English callout. A message made almost only of these is never sent for
-- auto-translation; Google happily "translates" things like "gg ez" (Hungarian) or "bag on van" (Dutch).
ChatTranslator.KNOWN_WORDS = {}
for word in ([[
a an the and or but if so to of in on at by for from with without into onto up down out off over under about
after before again here there where when what who why how which this that these those it its is are was were be
been being am do does did done doing have has had having can could will would should may might must not yes yeah
yea yep yup nope ok okay oki k kk i me my mine you your yours u ur he him his she her they them their we us our
all any some more most less much many one two three four five first last next other just only also too very
really still now then soon later already always never ever again back away get got go going gone come came coming
let lets make made take took give gave need needs want wanted know knew think thought see saw look looking wait
waiting stop start stay keep put use used try trying help leave left right wrong sorry thanks thank please pls plz
ty tyvm thx np nvm idk idc imo btw brb afk gg ggs ggwp ez wp gj nice good great bad cool fine sure lol lmao lmfao
rofl xd xdd hehe haha hahaha omg wtf bruh bro bros dude man guys guy everyone anyone someone nobody im dont cant
wont didnt doesnt isnt arent wasnt thats whats youre theyre ill ive id hey hi hello yo sup bye cya gn gl hf rip f
oops oh ah uh um hmm hm yes no mb my bad true lets go gogo gogogo fast quick slow faster hurry careful watch
ecm ecms pager pagers cam cams camera cameras guard guards civ civs civilian civilians hostage hostages tie ties
cable zip bag bags bagged loot van escape heli helicopter vault drill drills saw thermite c4 keycard keycards code
codes stealth loud dozer dozers cloaker cloakers taser tasers shield shields sniper snipers medic medics captain
winters cop cops swat fbi gensec spawn spawns ammo health med medbag doc doctor kit kits fak aid sentry sentries
jammer feedback downed revive res rez custody trade traded heist job host lobby kick kicked ready level infamy perk
deck skills skill build mask masks weapon weapons gun guns secure secured answer answered alarm detected detection
spotted mark marked body bodies dead kill killed shoot shot fire stairs roof room door doors window boat car truck
plane server box safe deposit gold money cash coke meth cook cooking ingredient ingredients hp dmg dlc solo pro
noob noobs carry throw jump min mins sec secs dw ds od mh ovk pd2 bot bots hacker cheater cheat mod mods modded
]]):gmatch("%S+") do
    ChatTranslator.KNOWN_WORDS[word] = true
end

-- Request limits for auto-translation, so a chat spammer cannot pile up web requests
ChatTranslator.MAX_IN_FLIGHT = 2
ChatTranslator.MAX_QUEUED = 6
ChatTranslator.REQUEST_TIMEOUT = 15
ChatTranslator.MIN_CONFIDENCE = 0.5
ChatTranslator.CACHE_LIMIT = 200
ChatTranslator.NOTE_NAME = "TL"

ChatTranslator._mod_path = ModPath
ChatTranslator._languages_file = ChatTranslator._mod_path .. "languages.json"
ChatTranslator._save_path = SavePath
ChatTranslator._save_file = ChatTranslator._save_path .. "chat_translator.json"

local function deep_copy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == "table" then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deep_copy(orig_key)] = deep_copy(orig_value)
        end
        setmetatable(copy, deep_copy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

function ChatTranslator:Setup()
    if not self.settings then
        self:Load()
        self.LoadLanguages()
        self.LoadGlossary()
    end

    HSAS = HSAS or {}

    self.SetupHooks()
end

function ChatTranslator:Load()
    self.settings = deep_copy(self.default_settings)
    local file = io.open(self._save_file, "r")
    if file then
        local data = file:read("*a")
        if data then
            local decoded_data = json.decode(data)

            if type(decoded_data) == "table" then
                for key, value in pairs(self.settings) do
                    if decoded_data[key] ~= nil and type(decoded_data[key]) == type(value) then
                        self.settings[key] = decoded_data[key]
                    end
                end
            end
        end
        file:close()
    end
end

function ChatTranslator:Save()
    local file = io.open(self._save_file, "w+")
    if file then
        file:write(json.encode(self.settings))
        file:close()
    end
end

-- The chat HUD is identified from the HUDChat class itself so that the mod always follows whichever
-- HUD mod actually owns the chat, no matter what the saved setting says or in which order mods load.
function ChatTranslator.DetectHUD()
    if HUDChat then
        if HUDChat._layout_custom_output_panel then
            return ChatTranslator.HUD.VOIDUI
        elseif HUDChat.MAX_OUTPUT_LINES then
            return WolfHUD and ChatTranslator.HUD.WOLFHUD or ChatTranslator.HUD.VANILLAHUD
        end

        return ChatTranslator.HUD.DEFAULT
    end

    -- HUDChat only exists ingame, fall back to the HUD mods themselves in the menu state
    if VoidUI and VoidUI.options and VoidUI.options.enable_chat then
        return ChatTranslator.HUD.VOIDUI
    elseif WolfHUD then
        return ChatTranslator.HUD.WOLFHUD
    elseif VHUDPlus and VHUDPlus:getSetting({"HUDChat", "ENABLED"}, true) then
        return ChatTranslator.HUD.VANILLAHUD
    end

    return ChatTranslator.HUD.DEFAULT
end

function ChatTranslator.ResolveHUD()
    local detected = ChatTranslator.DetectHUD()

    ChatTranslator.hud = detected
    ChatTranslator.can_extend_chat = detected == ChatTranslator.HUD.DEFAULT
    ChatTranslator.can_use_mouse_pointer = detected == ChatTranslator.HUD.DEFAULT or detected ==
                                               ChatTranslator.HUD.WOLFHUD

    return detected
end

function ChatTranslator.GetHUD()
    return ChatTranslator.hud or ChatTranslator.ResolveHUD()
end

function ChatTranslator.LoadLanguages()
    ChatTranslator.languages = {
        codes = {},
        name_ids = {},
        names = {},
        by_code = {}
    }

    local file = io.open(ChatTranslator._languages_file, "r")
    if file then
        local data = file:read("*a")
        if data then
            local decoded_data = json.decode(data)

            if decoded_data then
                local list = {}
                for key, value in pairs(decoded_data) do
                    table.insert(list, {
                        code = key,
                        name = value.name
                    })
                end

                table.sort(list, function(entry1, entry2)
                    return entry1.name < entry2.name
                end)

                for i, value in ipairs(list) do
                    table.insert(ChatTranslator.languages.codes, value.code)
                    table.insert(ChatTranslator.languages.name_ids, "chat_translator_" .. value.name)
                    table.insert(ChatTranslator.languages.names, value.name)
                    ChatTranslator.languages.by_code[value.code] = value.name
                end
            end
        end
        file:close()
    end

    for code, name in pairs(ChatTranslator.EXTRA_LANGUAGES) do
        ChatTranslator.languages.by_code[code] = ChatTranslator.languages.by_code[code] or name
    end
end

-- "pt-BR" -> "pt", "zh-CN" -> "zh"
function ChatTranslator.BaseCode(code)
    return type(code) == "string" and code:lower():match("^%a+") or nil
end

-- Returns the language code Google expects, or nil if the code is not known
function ChatTranslator.ResolveLanguage(token)
    if type(token) ~= "string" then
        return nil
    end

    local lower = token:lower()
    if ChatTranslator.ALIASES[lower] then
        return ChatTranslator.ALIASES[lower]
    end

    if ChatTranslator.languages and ChatTranslator.languages.by_code[lower] then
        return lower
    end

    return nil
end

function ChatTranslator.LanguageName(code)
    local name = ChatTranslator.languages and ChatTranslator.languages.by_code[code]
    return name or code
end

function ChatTranslator.EncodeUrl(message)
    if message == nil then
        return nil
    end

    local char_to_hex = function(c)
        return string.format("%%%02X", string.byte(c))
    end

    message = message:gsub("\n", "\r\n")
    message = message:gsub("([^%w _%%%-%.~])", char_to_hex)
    message = message:gsub(" ", "+")
    return message
end

-- Google's reply is an array with nulls in it; BLT's json decoder drops the nulls, which leaves
-- [1] = translated segments, [2] = detected source language, [3] = detection confidence.
function ChatTranslator.ParseResponse(data)
    if type(data) ~= "string" or data == "" then
        return nil
    end

    local decoded_data = json.decode(data)
    if type(decoded_data) ~= "table" or type(decoded_data[1]) ~= "table" or type(decoded_data[2]) ~= "string" then
        return nil
    end

    local parts = {}
    for _, segment in ipairs(decoded_data[1]) do
        if type(segment) == "table" and type(segment[1]) == "string" then
            table.insert(parts, segment[1])
        end
    end

    local text = table.concat(parts)
    if text == "" then
        return nil
    end

    return {
        source = decoded_data[2],
        text = text,
        confidence = type(decoded_data[3]) == "number" and decoded_data[3] or nil
    }
end

ChatTranslator._cache = ChatTranslator._cache or {}
ChatTranslator._cache_size = ChatTranslator._cache_size or 0
ChatTranslator._pending = ChatTranslator._pending or {}
ChatTranslator._in_flight = ChatTranslator._in_flight or {}
ChatTranslator._queue = ChatTranslator._queue or {}

local function call_safely(callback, ...)
    local ok, err = pcall(callback, ...)
    if not ok then
        log("[Chat Translator] callback error: " .. tostring(err))
    end
end

function ChatTranslator.CountInFlight()
    local count = 0
    for _ in pairs(ChatTranslator._in_flight) do
        count = count + 1
    end
    return count
end

function ChatTranslator.FinishRequest(key, result)
    ChatTranslator._in_flight[key] = nil

    local callbacks = ChatTranslator._pending[key]
    ChatTranslator._pending[key] = nil

    if result then
        if ChatTranslator._cache_size >= ChatTranslator.CACHE_LIMIT then
            ChatTranslator._cache = {}
            ChatTranslator._cache_size = 0
        end
        if not ChatTranslator._cache[key] then
            ChatTranslator._cache_size = ChatTranslator._cache_size + 1
        end
        ChatTranslator._cache[key] = result
    end

    for _, callback in ipairs(callbacks or {}) do
        call_safely(callback, result)
    end
end

-- A request that never answers would otherwise hold its slot forever
function ChatTranslator.ExpireRequests()
    local now = os.time()
    for key, started in pairs(ChatTranslator._in_flight) do
        if now - started > ChatTranslator.REQUEST_TIMEOUT then
            ChatTranslator.FinishRequest(key, nil)
        end
    end
end

function ChatTranslator.StartRequest(language, message, key)
    ChatTranslator._in_flight[key] = os.time()

    local url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" ..
                    ChatTranslator.EncodeUrl(language) .. "&dt=t&q=" .. ChatTranslator.EncodeUrl(message)

    dohttpreq(url, function(data)
        -- Ignore a late answer for a request that already timed out
        if not ChatTranslator._in_flight[key] then
            return
        end

        ChatTranslator.FinishRequest(key, ChatTranslator.ParseResponse(data))
        ChatTranslator.StartQueued()
    end)
end

function ChatTranslator.StartQueued()
    ChatTranslator.ExpireRequests()

    while #ChatTranslator._queue > 0 and ChatTranslator.CountInFlight() < ChatTranslator.MAX_IN_FLIGHT do
        local item = table.remove(ChatTranslator._queue, 1)
        ChatTranslator.StartRequest(item.language, item.message, item.key)
    end
end

-- callback(result) gets {source, text, confidence}, or nil when the translation failed.
-- Background requests (auto-translate) wait their turn and are dropped when the queue is full;
-- requests the player asked for start right away. Returns false when the request was dropped.
function ChatTranslator.Translate(language, message, callback, background)
    if type(message) ~= "string" or message == "" then
        return false
    end

    local key = language .. "\n" .. message

    local cached = ChatTranslator._cache[key]
    if cached then
        call_safely(callback, cached)
        return true
    end

    local waiting = ChatTranslator._pending[key]
    if waiting then
        table.insert(waiting, callback)
        return true
    end

    ChatTranslator.ExpireRequests()

    if background and ChatTranslator.CountInFlight() >= ChatTranslator.MAX_IN_FLIGHT then
        if #ChatTranslator._queue >= ChatTranslator.MAX_QUEUED then
            return false
        end

        ChatTranslator._pending[key] = {callback}
        table.insert(ChatTranslator._queue, {
            language = language,
            message = message,
            key = key
        })
        return true
    end

    ChatTranslator._pending[key] = {callback}
    ChatTranslator.StartRequest(language, message, key)
    return true
end

-- Shows a line in your own chat only; nothing is sent to the other players
function ChatTranslator.Notify(text, channel_id)
    if not managers.chat or not managers.chat._receive_message then
        return
    end

    ChatTranslator._notifying = true
    local ok, err = pcall(managers.chat._receive_message, managers.chat, channel_id or ChatManager.GAME,
        ChatTranslator.NOTE_NAME, text, Color(0.55, 0.85, 1))
    ChatTranslator._notifying = false

    if not ok then
        log("[Chat Translator] could not show a chat note: " .. tostring(err))
    end
end

function ChatTranslator.ShowHelp(channel_id)
    local keyword = ChatTranslator.settings.keyword
    local notify = function(text)
        ChatTranslator.Notify(text, channel_id)
    end

    notify(keyword .. " <code> <message>   e.g. " .. keyword .. " es where is the bag")

    for _, group in ipairs(ChatTranslator.HELP_GROUPS) do
        local entries = {}
        for _, code in ipairs(group.codes) do
            table.insert(entries, code .. " " .. ChatTranslator.LanguageName(code))
        end
        notify(group.label .. ": " .. table.concat(entries, ", "))
    end

    notify("Also works: jp kr cn ua br cz gr se dk")
    notify(keyword .. " auto = auto-translate on/off (now " .. (ChatTranslator.settings.auto_translate and "ON" or "OFF") ..
               "). Translated lines show the language after the name; click one for the original.")
end

function ChatTranslator.SetAutoTranslate(enabled)
    ChatTranslator.settings.auto_translate = enabled and true or false
    ChatTranslator:Save()

    local menu = MenuHelper and MenuHelper.GetMenu and MenuHelper:GetMenu("chat_translator")
    for _, item in pairs(menu and menu._items_list or {}) do
        if item:name() == "chat_translator_auto_translate" then
            item:set_value(ChatTranslator.settings.auto_translate and "on" or "off")
        end
    end
end

------------------------------------------------------------------------------------------------------------------------
-- PAYDAY 2 glossary (glossary.json)
--
-- Google has no idea this is PAYDAY 2: "cams" becomes camshafts, "doc bag" a document bag, "rez me" a prayer.
-- Before a message goes to Google:
--   * "rewrite" phrases (gamer slang) are replaced by plain English that Google translates well;
--   * "terms" (game items, enemies, mechanics) are swapped for placeholders like X1X, which Google leaves alone
--     and builds the sentence around. Afterwards each placeholder becomes the name the reader knows: the game's
--     own name in their language when one is listed, otherwise the English name used in every PD2 lobby.
-- The same terms work backwards for incoming messages: a listed foreign name becomes the English game name.
------------------------------------------------------------------------------------------------------------------------

ChatTranslator._glossary_file = ChatTranslator._mod_path .. "glossary.json"
ChatTranslator.PLACEHOLDER_FORMAT = "X%dX"

-- Lower-cases ASCII, Latin-1 accented capitals, Greek and Cyrillic capitals so "Глушилка" matches "глушилка"
local function utf8_lower(text)
    text = text:lower()
    return (text:gsub("[\195\206\207\208][\128-\191]", function(char)
        local b1, b2 = char:byte(1, 2)
        if b1 == 195 and b2 >= 128 and b2 <= 158 and b2 ~= 151 then
            return string.char(195, b2 + 32) -- À-Þ -> à-þ
        elseif b1 == 208 and b2 >= 144 and b2 <= 159 then
            return string.char(208, b2 + 32) -- А-П -> а-п
        elseif b1 == 208 and b2 >= 160 and b2 <= 175 then
            return string.char(209, b2 - 32) -- Р-Я -> р-я
        elseif b1 == 208 and b2 >= 128 and b2 <= 143 then
            return string.char(209, b2 + 16) -- Ѐ-Џ (Ё, Є, І, Ї...) -> ѐ-џ
        elseif b1 == 206 and b2 >= 145 and b2 <= 159 then
            return string.char(206, b2 + 32) -- Α-Ο -> α-ο
        elseif b1 == 206 and b2 >= 160 and b2 <= 169 then
            return string.char(207, b2 - 32) -- Π-Ω -> π-ω
        end
        return char
    end))
end

local function split_words(phrase)
    local words = {}
    for word in utf8_lower(phrase):gsub("%-", " "):gmatch("%S+") do
        table.insert(words, word)
    end
    return words
end

function ChatTranslator.LoadGlossary()
    local glossary = {
        out = {}, -- English phrase -> {rewrite = text} or {term = term, plural = bool}
        incoming = {}, -- foreign phrase -> {term = term, plural = bool}
        incoming_cjk = {}, -- {phrase, value} for CJK names, longest first
        english_fix = {}, -- phrase in Google's English output -> better wording
        hinted = {}, -- {name, hint} for names carrying an English hint: "генератор помех (ECM)"
        hints = {}, -- set of those hints, lower-case
        max_words = 1
    }
    ChatTranslator.glossary = glossary

    local file = io.open(ChatTranslator._glossary_file, "r")
    if not file then
        return
    end
    local decoded = json.decode(file:read("*a") or "")
    file:close()

    if type(decoded) ~= "table" then
        log("[Chat Translator] glossary.json could not be read, the glossary is off")
        return
    end

    local function add(map, phrase, value)
        if type(phrase) ~= "string" or phrase == "" then
            return
        end
        -- "генератор помех (ECM)" is matched as "генератор помех"
        local words = split_words(phrase:gsub("%b()", ""))
        if #words == 0 then
            return
        end

        local hint = map == glossary.incoming and phrase:match("%(%s*(.-)%s*%)")
        if hint and hint ~= "" then
            hint = utf8_lower(hint)
            glossary.hints[hint] = true
            table.insert(glossary.hinted, {
                name = table.concat(words, " "),
                hint = hint
            })
        end

        -- Chinese and Japanese have no spaces (and Korean glues particles on), so their names are found by
        -- substring instead of by whole words
        if map == glossary.incoming and phrase:find("[\227-\237][\128-\191][\128-\191]") then
            table.insert(glossary.incoming_cjk, {
                phrase = table.concat(words, " "),
                value = value
            })
            return
        end
        glossary.max_words = math.max(glossary.max_words, #words)
        map[table.concat(words, " ")] = value
    end

    for phrase, replacement in pairs(type(decoded.rewrite) == "table" and decoded.rewrite or {}) do
        add(glossary.out, phrase, {
            rewrite = replacement
        })
    end

    for phrase, replacement in pairs(type(decoded.english_fix) == "table" and decoded.english_fix or {}) do
        add(glossary.english_fix, phrase, {
            rewrite = replacement
        })
    end

    -- Words left exactly as typed (gg, afk, lol...): every player knows them, Google does not
    local terms = type(decoded.terms) == "table" and decoded.terms or {}
    for _, word in ipairs(type(decoded.keep) == "table" and decoded.keep or {}) do
        if type(word) == "string" then
            table.insert(terms, {
                en = word,
                match = {word}
            })
        end
    end

    for _, entry in ipairs(terms) do
        if type(entry) == "table" and type(entry.en) == "string" then
            local term = {
                en = entry.en,
                en_plural = entry.en_plural or entry.en,
                -- "english": readers without a listed name get the English game name (ECM, dozer, cloaker...)
                -- "translate": readers without a listed name get Google's normal translation (drill, keycard...)
                fallback = entry.fallback == "translate" and "translate" or "english",
                names = type(entry.names) == "table" and entry.names or {},
                names_plural = type(entry.names_plural) == "table" and entry.names_plural or {}
            }

            for _, phrase in ipairs(entry.match or {}) do
                add(glossary.out, phrase, {
                    term = term,
                    plural = false
                })
            end
            for _, phrase in ipairs(entry.match_plural or {}) do
                add(glossary.out, phrase, {
                    term = term,
                    plural = true
                })
            end

            -- Incoming: the official names plus any other forms players write (case endings, slang).
            -- Only for game jargon; Google already handles "drill" or "doctor bag" in any language, and
            -- names like "combate" (loud) are everyday words that must not be turned into game terms.
            local incoming = entry.incoming
            if incoming == nil then
                incoming = term.fallback == "english"
            end
            for _, name in pairs(incoming and term.names or {}) do
                add(glossary.incoming, name, {
                    term = term,
                    plural = false
                })
            end
            for _, name in pairs(incoming and term.names_plural or {}) do
                add(glossary.incoming, name, {
                    term = term,
                    plural = true
                })
            end
            for _, forms in pairs(incoming and type(entry.forms) == "table" and entry.forms or {}) do
                for _, form in ipairs(type(forms) == "table" and forms or {forms}) do
                    add(glossary.incoming, form, {
                        term = term,
                        plural = false
                    })
                end
            end
        end
    end

    table.sort(glossary.incoming_cjk, function(a, b)
        return #a.phrase > #b.phrase
    end)
end

-- Finds glossary phrases in text (longest phrase first, whole words only, words separated by spaces or hyphens)
-- and returns the text rebuilt by replace(entry, original_phrase).
local function glossary_replace(text, map, replace)
    local glossary = ChatTranslator.glossary
    if not glossary or not next(map) then
        return text, 0
    end

    local tokens = {}
    for start, word, finish in text:gmatch("()([%w\128-\255']+)()") do
        table.insert(tokens, {
            s = start,
            e = finish,
            lower = utf8_lower(word)
        })
    end

    local pieces, cursor, count, i = {}, 1, 0, 1
    while i <= #tokens do
        local matched = false
        for n = math.min(glossary.max_words, #tokens - i + 1), 1, -1 do
            local words, joined_cleanly = {}, true
            for k = i, i + n - 1 do
                table.insert(words, tokens[k].lower)
                if k > i and not text:sub(tokens[k - 1].e, tokens[k].s - 1):match("^[%s%-]+$") then
                    joined_cleanly = false
                    break
                end
            end

            local entry = joined_cleanly and map[table.concat(words, " ")]
            if entry then
                local first, last = tokens[i], tokens[i + n - 1]
                table.insert(pieces, text:sub(cursor, first.s - 1))
                table.insert(pieces, replace(entry, text:sub(first.s, last.e - 1)))
                cursor = last.e
                count = count + 1
                i = i + n
                matched = true
                break
            end
        end

        if not matched then
            i = i + 1
        end
    end

    table.insert(pieces, text:sub(cursor))
    return table.concat(pieces), count
end

-- The reader's name for a term, or nil when none is listed for that language
local function listed_name(term, language, plural)
    local base = ChatTranslator.BaseCode(language)
    local name = plural and (term.names_plural[language] or term.names_plural[base])
    return name or term.names[language] or term.names[base]
end

function ChatTranslator.TermName(term, language, plural)
    if ChatTranslator.BaseCode(language) ~= "en" then
        local name = listed_name(term, language, plural)
        if name then
            return name
        end
    end
    return plural and term.en_plural or term.en
end

-- Returns the text to send to Google and the list of protected terms
function ChatTranslator.ProtectText(text, direction, language)
    local glossary = ChatTranslator.glossary
    if not glossary then
        return text, {}
    end

    local english_reader = ChatTranslator.BaseCode(language) == "en"

    local slots = {}

    if direction ~= "out" then
        -- Another player of this mod sends "генератор помех (ECM)": drop the hint before matching, otherwise
        -- the English reader sees "ECM (ECM)" (and "(pager)" would be matched as a second term)
        local function strip_hint(position, hint)
            hint = utf8_lower(hint)
            if not glossary.hints[hint] then
                return nil
            end
            local before = utf8_lower(text:sub(1, position - 1)):gsub("%-", " ")
            for _, hinted in ipairs(glossary.hinted) do
                if hinted.hint == hint and before:sub(-#hinted.name) == hinted.name then
                    return ""
                end
            end
            return nil
        end
        text = text:gsub("()%s*%(%s*(%a[%a%s]-)%s*%)", strip_hint)
        text = text:gsub("()%s*\239\188\136%s*(%a[%a%s]-)%s*\239\188\137", strip_hint)

        for _, cjk in ipairs(glossary.incoming_cjk) do
            local start, finish = text:find(cjk.phrase, 1, true)
            while start do
                table.insert(slots, cjk.value)
                local placeholder = " " .. string.format(ChatTranslator.PLACEHOLDER_FORMAT, #slots) .. " "
                text = text:sub(1, start - 1) .. placeholder .. text:sub(finish + 1)
                start, finish = text:find(cjk.phrase, start + #placeholder, true)
            end
        end
    end

    local protected = glossary_replace(text, direction == "out" and glossary.out or glossary.incoming,
        function(entry, original)
            if entry.rewrite then
                return entry.rewrite
            end
            -- Let Google translate the clean English name ("doc bag" -> "doctor bag") when we have nothing
            -- better for this reader
            if direction == "out" and entry.term.fallback == "translate" and not english_reader and
                not listed_name(entry.term, language, entry.plural) then
                return entry.plural and entry.term.en_plural or entry.term.en
            end
            table.insert(slots, entry)
            return string.format(ChatTranslator.PLACEHOLDER_FORMAT, #slots)
        end)

    if direction ~= "out" and #slots > 0 then
        -- Drop the English hint this mod adds after official names ("генератор помех (ECM)"), otherwise
        -- the English reader sees "ECM (ECM)"
        local function drop_known_hint(placeholder, hint)
            if glossary.hints[utf8_lower(hint)] then
                return placeholder
            end
            return nil
        end
        protected = protected:gsub("(X%d+X)%s*%(%s*(%a[%a%s]-)%s*%)", drop_known_hint)
        protected = protected:gsub("(X%d+X)%s*\239\188\136%s*(%a[%a%s]-)%s*\239\188\137", drop_known_hint)
    end

    return protected, slots
end

-- Letters Google sometimes swaps the placeholder's X for: Cyrillic Х х, Greek Χ χ, fullwidth Ｘ ｘ
local PLACEHOLDER_LOOKALIKES = {"\208\165", "\209\133", "\206\167", "\207\135", "\239\188\184", "\239\189\152"}

-- Puts the reader's names back in place of the placeholders. Returns nil if Google lost one of them.
function ChatTranslator.RestoreText(text, slots, language)
    if #slots > 0 then
        for _, lookalike in ipairs(PLACEHOLDER_LOOKALIKES) do
            text = text:gsub(lookalike .. "(%s?%d+%s?)" .. lookalike, "X%1X")
        end
    end

    for index = #slots, 1, -1 do
        local slot = slots[index]
        local name = ChatTranslator.TermName(slot.term, language, slot.plural):gsub("%%", "%%%%")
        local found
        text, found = text:gsub("[Xx]%s?" .. index .. "%s?[Xx]", name)
        if found == 0 then
            return nil
        end
    end

    if ChatTranslator.BaseCode(language) == "en" and ChatTranslator.glossary then
        text = glossary_replace(text, ChatTranslator.glossary.english_fix, function(entry)
            return entry.rewrite
        end)
    end

    return text
end

-- Translate with the glossary. direction is "out" for your own messages, "in" for other players' messages.
-- If Google drops a placeholder, the message is translated again without the glossary rather than lost.
function ChatTranslator.TranslateChat(language, text, direction, callback, background)
    local protected, slots = ChatTranslator.ProtectText(text, direction, language)
    if protected == text and #slots == 0 then
        return ChatTranslator.Translate(language, text, function(result)
            if result and ChatTranslator.BaseCode(language) == "en" then
                result = {
                    source = result.source,
                    confidence = result.confidence,
                    text = ChatTranslator.RestoreText(result.text, {}, language) or result.text
                }
            end
            callback(result)
        end, background)
    end

    -- Nothing left for Google once the protected words are out ("gg ez", "ECM!"): no request needed
    local leftover = protected:gsub("X%d+X", "")
    if direction == "out" and not leftover:find("[%a\128-\255]") then
        local restored = ChatTranslator.RestoreText(protected, slots, language)
        if restored then
            call_safely(callback, {
                source = "en",
                text = restored
            })
            return true
        end
    end

    return ChatTranslator.Translate(language, protected, function(result)
        if not result then
            return callback(nil)
        end

        local restored = ChatTranslator.RestoreText(result.text, slots, language)
        if restored then
            return callback({
                source = result.source,
                confidence = result.confidence,
                text = restored
            })
        end

        log("[Chat Translator] placeholder lost, translating without the glossary: " .. tostring(result.text))
        if not ChatTranslator.Translate(language, text, callback, background) then
            callback(nil)
        end
    end, background)
end

function ChatTranslator.ProcessInput(object, channel_id, sender, message)
    local keyword = ChatTranslator.settings.keyword
    if type(message) ~= "string" or message:sub(1, #keyword):lower() ~= keyword:lower() then
        return false
    end

    local rest = message:sub(#keyword + 1)
    if rest ~= "" and not rest:find("^%s") then
        -- "tl;dr", "tlou" and the like are normal messages
        return false
    end

    local token, text = rest:match("^%s*(%S+)%s*(.-)%s*$")
    local lower = token and token:lower()

    if not token or lower == "help" or lower == "?" or lower == "h" then
        ChatTranslator.ShowHelp(channel_id)
        return true
    end

    if lower == "auto" then
        ChatTranslator.SetAutoTranslate(not ChatTranslator.settings.auto_translate)
        ChatTranslator.Notify("Auto-translate is now " .. (ChatTranslator.settings.auto_translate and "ON" or "OFF") ..
                                  ".", channel_id)
        return true
    end

    local language = ChatTranslator.ResolveLanguage(token)
    if not language then
        ChatTranslator.Notify("Unknown language code '" .. token .. "', nothing was sent. Type '" .. keyword ..
                                  " help' for the list.", channel_id)
        return true
    end

    if text == "" then
        ChatTranslator.Notify("Nothing to translate. Example: " .. keyword .. " " .. token .. " hello everyone",
            channel_id)
        return true
    end

    ChatTranslator.TranslateChat(language, text, "out", function(result)
        if not result then
            ChatTranslator.Notify("Translation failed (no answer from Google), nothing was sent: " .. text, channel_id)
            return
        end

        -- Already written in that language: send it as typed
        local outgoing = result.text
        if ChatTranslator.BaseCode(result.source) == ChatTranslator.BaseCode(language) then
            outgoing = text
        end

        ChatTranslator._ChatManager_send_message(object, channel_id, sender, outgoing)
    end)
    return true
end

local function utf8_codepoint(char)
    local length = #char
    local b1 = char:byte(1)
    if length == 2 then
        return (b1 % 32) * 64 + char:byte(2) % 64
    elseif length == 3 then
        return (b1 % 16) * 4096 + (char:byte(2) % 64) * 64 + char:byte(3) % 64
    elseif length == 4 then
        return (b1 % 8) * 262144 + (char:byte(2) % 64) * 4096 + (char:byte(3) % 64) * 64 + char:byte(4) % 64
    end
    return nil
end

-- Letters of non-English alphabets: accented Latin, Greek, Cyrillic, Arabic, Thai, Vietnamese, CJK, Hangul.
-- Symbols, punctuation, emoji and kaomoji pieces are not letters.
local function is_foreign_letter(char)
    local cp = utf8_codepoint(char)
    if not cp then
        return false
    end

    return (cp >= 0xC0 and cp <= 0x24F and cp ~= 0xD7 and cp ~= 0xF7) or (cp >= 0x370 and cp <= 0x1FFF) or
               (cp >= 0x3040 and cp <= 0x9FFF and cp ~= 0x30FB) or (cp >= 0xAC00 and cp <= 0xD7AF) or
               (cp >= 0xF900 and cp <= 0xFAFF)
end

-- Cheap local check done before any web request: is this message worth asking Google about?
-- Callouts, slang, numbers, links and one-word messages are not.
function ChatTranslator.LooksTranslatable(message)
    if type(message) ~= "string" or message == "" or #message > 600 then
        return false
    end

    local text = message:gsub("%a+://%S+", " "):gsub("www%.%S+", " ")

    local words, known, foreign_letters, ascii_letters = 0, 0, 0, 0
    for word in text:gmatch("[%a\128-\255']+") do
        local word_foreign = 0
        for char in word:gmatch("[\192-\247][\128-\191]*") do
            if is_foreign_letter(char) then
                word_foreign = word_foreign + 1
            end
        end

        local _, word_ascii = word:gsub("%a", "")

        if word_foreign + word_ascii > 0 then
            words = words + 1
            foreign_letters = foreign_letters + word_foreign
            ascii_letters = ascii_letters + word_ascii

            if word_foreign == 0 and ChatTranslator.KNOWN_WORDS[word:lower():gsub("'", "")] then
                known = known + 1
            end
        end
    end

    if words == 0 then
        return false
    end

    -- Two letters of another alphabet are enough ("да", "はい", "好的")
    if foreign_letters >= 2 then
        return true
    end

    if words < 2 or ascii_letters + foreign_letters < 5 then
        return false
    end

    return known / words < 0.75
end

local function normalize_for_compare(text)
    return (text:lower():gsub("[%s%p]", ""))
end

-- Decides whether an auto-translation is shown, so you only ever see translations that add something
function ChatTranslator.IsWorthShowing(original, result, language)
    local source = ChatTranslator.BaseCode(result.source)
    if not source or source == ChatTranslator.BaseCode(language) then
        return false
    end

    if ChatTranslator.settings.auto_exclude[source] then
        return false
    end

    if result.confidence and result.confidence < ChatTranslator.MIN_CONFIDENCE then
        return false
    end

    return normalize_for_compare(original) ~= normalize_for_compare(result.text)
end

-- The message currently being delivered from another player (set around ChatManager:receive_message_by_peer)
function ChatTranslator.IsFromOtherPlayer(message)
    return ChatTranslator._incoming_message ~= nil and ChatTranslator._incoming_message == message
end

function ChatTranslator.ConsiderAutoTranslate(translatable_message, message)
    if not ChatTranslator.settings.auto_translate or ChatTranslator._notifying then
        return
    end

    if not ChatTranslator.IsFromOtherPlayer(message) or not ChatTranslator.LooksTranslatable(message) then
        return
    end

    translatable_message:AutoTranslate()
end

function ChatTranslator.UpdateButtons()
    local hud = ChatTranslator.ResolveHUD()

    local chat_extendable = hud == ChatTranslator.HUD.DEFAULT

    local mouse_pointer_enableable = hud == ChatTranslator.HUD.DEFAULT or hud == ChatTranslator.HUD.WOLFHUD

    for _, item in pairs(MenuHelper:GetMenu("chat_translator")._items_list) do
        if item:name() == "chat_translator_extend_chat" then
            item:set_value(ChatTranslator.settings.extend_chat and chat_extendable and "on" or "off")
            item:set_enabled(chat_extendable)
        elseif item:name() == "chat_translator_mouse_pointer" then
            item:set_value(ChatTranslator.settings.mouse_pointer and mouse_pointer_enableable and "on" or "off")
            item:set_enabled(mouse_pointer_enableable)
        end
    end
end

function ChatTranslator:Warn()
    local dialog_data = {
        title = managers.localization:text("dialog_warning_title"),
        text = managers.localization:text("chat_translator_warning_hud_missing")
    }

    local ok_button = {
        text = managers.localization:text("dialog_ok")
    }

    dialog_data.button_list = {ok_button}

    managers.system_menu:show(dialog_data)
end

function ChatTranslator:CheckHUDCompatibility()
    if self.settings.hud ~= ChatTranslator.HUD.AUTO and self.settings.hud ~= ChatTranslator.ResolveHUD() then
        ChatTranslator:Warn()
    end
end

function ChatTranslator:mouse_moved(x, y)
    local output_panel = alive(self._panel) and self._panel:child("output_panel")
    if not output_panel or not output_panel:inside(x, y) then
        managers.mouse_pointer:set_pointer_image("arrow")
        return false
    end

    if self._chat_type ~= ChatTranslator.CHAT_TYPE.CHATGUI and ChatTranslator.GetHUD() ==
        ChatTranslator.HUD.VOIDUI then
        local inside = false
        for i = #self._lines, 1, -1 do
            local panel = self._lines[i].panel
            if inside == false then
                inside = panel:inside(x, y)
            end
            panel:set_alpha(panel:inside(x, y) and 1 or 0.5)
        end
    end

    local translatable_messages = self._translatable_messages or {}
    for i = #translatable_messages, 1, -1 do
        local message = translatable_messages[i]

        if message:inside(x, y) then
            managers.mouse_pointer:set_pointer_image("link")
            return true
        end
    end

    managers.mouse_pointer:set_pointer_image("arrow")
    return false
end

function ChatTranslator:mouse_pressed(button, x, y)
    local output_panel = alive(self._panel) and self._panel:child("output_panel")
    if not output_panel or not output_panel:inside(x, y) then
        return false
    end

    -- The vanilla ingame chat has no mouse handling of its own, so scrolling is added here
    if ChatTranslator.settings.extend_chat and ChatTranslator.can_extend_chat and self._chat_type ==
        ChatTranslator.CHAT_TYPE.HUDCHAT then
        if button == Idstring("mouse wheel down") then
            local ret = self:scroll_down()
            self:set_scroll_indicators()
            return ret
        elseif button == Idstring("mouse wheel up") then
            local ret = self:scroll_up()
            self:set_scroll_indicators()
            return ret
        end
    end

    if button ~= Idstring("0") then
        return false
    end

    local translatable_messages = self._translatable_messages or {}
    for i = #translatable_messages, 1, -1 do
        local message = translatable_messages[i]

        if message:inside(x, y) then
            message:ToggleTranslation()
            self:_on_focus()
            return true
        end
    end

    return false
end

ChatTranslatorMessage = ChatTranslatorMessage or class()

function ChatTranslatorMessage:init(chat, line, name, message, color, icon)
    self._chat = chat
    self._line = line
    self._name = name
    self._message = message
    self._color = color
    self._icon = icon
    self._show_translation = false

    if self._chat._chat_type == ChatTranslator.CHAT_TYPE.HUDCHAT and ChatTranslator.GetHUD() ==
        ChatTranslator.HUD.VOIDUI then
        self._time_stamp = VoidUI.options.chattime == 2 and "[" ..
                               os.date("!%X", managers.game_play_central:get_heist_timer()) .. "] " or "[" ..
                               os.date("%X") .. "] "
    end
end

function ChatTranslatorMessage:inside(x, y)
    if not self._line then
        return false
    end

    if self._chat._chat_type == ChatTranslator.CHAT_TYPE.CHATGUI then
        return alive(self._line[2]) and self._line[2]:inside(x, y)
    elseif ChatTranslator.GetHUD() == ChatTranslator.HUD.DEFAULT then
        return alive(self._line[1]) and self._line[1]:inside(x, y)
    end

    return alive(self._line.panel) and self._line.panel:inside(x, y)
end

-- The chat line can be gone by the time Google answers (old lines trimmed, level loaded, HUD rebuilt)
function ChatTranslatorMessage:IsAlive()
    local chat = self._chat
    if not chat or not alive(chat._panel) or not self._line then
        return false
    end

    if chat._chat_type == ChatTranslator.CHAT_TYPE.CHATGUI then
        return alive(self._line[1]) and alive(self._line[2])
    elseif ChatTranslator.GetHUD() == ChatTranslator.HUD.DEFAULT then
        return alive(self._line[1])
    end

    return alive(self._line.panel)
end

function ChatTranslatorMessage:RequestTranslation()
    if self._translation_requested then
        return
    end

    self._translation_requested = true

    local language = ChatTranslator.settings.language
    ChatTranslator.TranslateChat(language, self._message, "in", function(result)
        if not result or ChatTranslator.BaseCode(result.source) == ChatTranslator.BaseCode(language) then
            -- Let a later click try again
            self._translation_requested = false
            return
        end

        self:ApplyTranslation(result.source, result.text)
    end)
end

function ChatTranslatorMessage:AutoTranslate()
    if self._translation_requested then
        return
    end

    self._translation_requested = true

    local language = ChatTranslator.settings.language
    local queued = ChatTranslator.TranslateChat(language, self._message, "in", function(result)
        if not result or not ChatTranslator.IsWorthShowing(self._message, result, language) then
            -- Left as it is; a click still translates it
            self._translation_requested = false
            return
        end

        self:ApplyTranslation(result.source, result.text)
    end, true)

    if not queued then
        self._translation_requested = false
    end
end

function ChatTranslatorMessage:ApplyTranslation(language, message)
    if self._translated or not self:IsAlive() then
        self._translation_requested = false
        return
    end

    self._translated = true

    self._language = language
    self._translated_message = message

    self:ToggleTranslation()
end

function ChatTranslatorMessage:ToggleTranslation()
    if not self._translated then
        self:RequestTranslation()
        return
    end

    self._show_translation = not self._show_translation

    local hud = ChatTranslator.GetHUD()

    local display_name = nil
    local display_message = nil
    if self._show_translation then
        display_name = self._name .. " (" .. self._language .. ")"
        display_message = self._translated_message
    else
        display_name = self._name
        display_message = self._message
    end

    if self._chat._chat_type == ChatTranslator.CHAT_TYPE.CHATGUI then
        local line = self._line[1]
        local line_bg = self._line[2]

        local len = utf8.len(display_name) + 1
        line:set_text(display_name .. ": " .. display_message)

        local total_len = utf8.len(line:text())

        line:set_range_color(0, len, self._color)
        line:set_range_color(len, total_len, Color.white)

        line:set_w(self._chat._panel:child("output_panel"):w() - line:left())

        local _, _, w, h = line:text_rect()

        line:set_h(h)
        line_bg:set_w(w + line:left() + 2)
        line_bg:set_h(self._chat.line_height * line:number_of_lines())
    elseif hud == ChatTranslator.HUD.DEFAULT then
        local line = self._line[1]

        local len = utf8.len(display_name) + 1
        line:set_text(display_name .. ": " .. display_message)

        local total_len = utf8.len(line:text())

        line:set_range_color(0, len, self._color)
        line:set_range_color(len, total_len, Color.white)
        line:set_kern(line:kern())
    elseif hud == ChatTranslator.HUD.WOLFHUD or hud == ChatTranslator.HUD.VANILLAHUD then
        local msg_panel = self._line.panel
        local message_text = msg_panel:child("msg")
        local msg_panel_bg = msg_panel:child("bg")

        message_text:set_text(display_name .. ": " .. display_message)
        local no_lines = message_text:number_of_lines()

        message_text:set_range_color(0, utf8.len(display_name) + 1, self._color)
        message_text:set_h(self._chat.LINE_HEIGHT * no_lines)
        message_text:set_kern(message_text:kern())
        msg_panel:set_h(self._chat.LINE_HEIGHT * no_lines)
        msg_panel_bg:set_h(self._chat.LINE_HEIGHT * no_lines)

        -- A translation can wrap over a different amount of lines than the original message
        if self._chat._total_message_lines and self._line.lines then
            self._chat._total_message_lines = self._chat._total_message_lines + no_lines - self._line.lines
            self._line.lines = no_lines
        end

        if not self._chat.COLORED_BG then
            local x_offset = HUDChat.COLORED_BG and 2 or 0
            local time_text = msg_panel:child("time")
            local _, _, w, _ = time_text:text_rect()
            x_offset = x_offset + w + 2
            local icon_bitmap = msg_panel:child("icon")
            if icon_bitmap then
                x_offset = x_offset + icon_bitmap:w() + 1
            end

            local _, _, msg_w, _ = message_text:text_rect()

            msg_panel_bg:set_width(x_offset + msg_w + 2)
        end
    elseif hud == ChatTranslator.HUD.VOIDUI then
        local name = self._line.name
        local peer =
            (managers.network and managers.network:session() and managers.network:session():local_peer():name() ==
                self._name and managers.network:session():local_peer()) or
                (managers.network and managers.network:session() and managers.network:session():peer_by_name(self._name))
        local character = self._line.character
        local full_message = display_name ..
                                 (VoidUI.options.show_charactername and peer and peer:character() and character or "") ..
                                 ": " .. display_message
        if self._name == managers.localization:to_upper_text("menu_system_message") then
            name = display_message
            full_message = display_message
        else
            name = display_name
        end

        if VoidUI.options.chattime > 1 and self._time_stamp then
            full_message = self._time_stamp .. full_message
            name = self._time_stamp .. name
        end
        local len = utf8.len(name) + (VoidUI.options.show_charactername and utf8.len(character) or 0) + 1

        local output_panel = self._chat._panel:child("output_panel")
        local panel = self._line.panel
        local line = panel:child("line")
        local line_shadow = panel:child("line_shadow")

        line:set_text(full_message)
        line_shadow:set_text(full_message)

        line_shadow:set_w(output_panel:w() - line:left())

        local total_len = utf8.len(line:text())
        local lines_count = line:number_of_lines()
        self._chat._lines_count = self._chat._lines_count + lines_count
        line:set_range_color(0, len, self._color)
        line:set_range_color(len, total_len, Color.white)
        panel:set_h(self._chat.line_height * self._chat._scale * lines_count)
        line:set_h(panel:h())
        line_shadow:set_h(panel:h())
    end

    if self._chat._chat_type == ChatTranslator.CHAT_TYPE.HUDCHAT and hud == ChatTranslator.HUD.VOIDUI then
        self._chat:_layout_custom_output_panel()
    else
        self._chat:_layout_output_panel()
    end
end

function ChatTranslator.SetupHooks()
    if RequiredScript == "lib/managers/chatmanager" then
        Hooks:PostHook(ChatGui, "init", "ChatTranslator_ChatGui_init", function(self)
            self._chat_type = ChatTranslator.CHAT_TYPE.CHATGUI
            self._translatable_messages = {}
        end)

        Hooks:PostHook(ChatGui, "receive_message", "ChatTranslator_ChatGui_receive_message",
            function(self, name, message, color, icon)
                local line = self._lines[#self._lines]

                local translatable_message = ChatTranslatorMessage:new(self, line, name, message, color, icon)
                table.insert(self._translatable_messages, translatable_message)

                ChatTranslator.ConsiderAutoTranslate(translatable_message, message)
            end)

        -- Only messages typed by another player in the lobby go through here (not your own, not system or
        -- mod notices), which is what auto-translate is limited to
        Hooks:PreHook(ChatManager, "receive_message_by_peer", "ChatTranslator_ChatManager_receive_message_by_peer",
            function(self, channel_id, peer, message)
                local session = managers.network and managers.network:session()
                local local_peer = session and session:local_peer()
                local from_other = peer and local_peer and peer.id and peer:id() ~= local_peer:id()

                ChatTranslator._incoming_message = from_other and message or nil
            end)
        Hooks:PostHook(ChatManager, "receive_message_by_peer",
            "ChatTranslator_ChatManager_receive_message_by_peer_post", function()
                ChatTranslator._incoming_message = nil
            end)

        ChatTranslator._ChatGui_mouse_moved = ChatGui.mouse_moved
        function ChatGui:mouse_moved(x, y)
            local inside, arrow = ChatTranslator._ChatGui_mouse_moved(self, x, y)
            if not inside and ChatTranslator.mouse_moved(self, x, y) then
                return true, "link"
            end

            return inside, arrow
        end

        Hooks:PreHook(ChatGui, "mouse_pressed", "ChatTranslator_ChatGui_mouse_pressed", ChatTranslator.mouse_pressed)

        ChatTranslator._ChatManager_send_message = ChatManager.send_message
        function ChatManager:send_message(channel_id, sender, message)
            if not ChatTranslator.ProcessInput(self, channel_id, sender, message) then
                ChatTranslator._ChatManager_send_message(self, channel_id, sender, message)
            end
        end
    elseif RequiredScript == "lib/managers/hud/hudchat" then
        local hud = ChatTranslator.ResolveHUD()

        if hud == ChatTranslator.HUD.VANILLAHUD and HUDChat._mouse_move then
            Hooks:PostHook(HUDChat, "_mouse_move", "ChatTranslator_HUDChat__mouse_move", function(self, _, x, y)
                x = x - self._x_offset
                y = y - self._y_offset
                ChatTranslator.mouse_moved(self, x, y)
            end)
            Hooks:PreHook(HUDChat, "_mouse_press", "ChatTranslator_HUDChat__mouse_press",
                function(self, _, button, x, y)
                    x = x - self._x_offset
                    y = y - self._y_offset
                    ChatTranslator.mouse_pressed(self, button, x, y)
                end)
        end

        Hooks:PostHook(HUDChat, "init", "ChatTranslator_HUDChat_init", function(self)
            -- Every mod has had its say by the time the chat is built, so this is the final word on the HUD
            ChatTranslator.ResolveHUD()

            self._chat_type = ChatTranslator.CHAT_TYPE.HUDCHAT
            self._translatable_messages = {}
        end)

        Hooks:PostHook(HUDChat, "receive_message", "ChatTranslator_HUDChat_receive_message",
            function(self, name, message, color, icon)
                local line = nil
                if ChatTranslator.GetHUD() == ChatTranslator.HUD.DEFAULT or ChatTranslator.GetHUD() ==
                    ChatTranslator.HUD.VOIDUI then
                    line = self._lines[#self._lines]
                else
                    line = self._messages[#self._messages]
                end

                local translatable_message = ChatTranslatorMessage:new(self, line, name, message, color, icon)
                table.insert(self._translatable_messages, translatable_message)

                ChatTranslator.ConsiderAutoTranslate(translatable_message, message)
            end)

        if HUDChat.mouse_moved then
            Hooks:PostHook(HUDChat, "mouse_moved", "ChatTranslator_HUDChat_mouse_moved",
                (hud ~= ChatTranslator.HUD.VOIDUI) and ChatTranslator.mouse_moved or function(self, _, x, y)
                    x =
                        x -
                            (managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2).panel:w() -
                                self._hud_panel:w()) / 2
                    y =
                        y -
                            (managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2).panel:h() -
                                self._hud_panel:h()) / 2
                    ChatTranslator.mouse_moved(self, x, y)
                end)
        else
            HUDChat.mouse_moved = ChatTranslator.mouse_moved
        end

        if HUDChat.mouse_pressed then
            Hooks:PreHook(HUDChat, "mouse_pressed", "ChatTranslator_HUDChat_mouse_pressed",
                (hud ~= ChatTranslator.HUD.VOIDUI) and ChatTranslator.mouse_pressed or
                    function(self, _, button, x, y)
                        x =
                            x -
                                (managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2).panel:w() -
                                    self._hud_panel:w()) / 2
                        y =
                            y -
                                (managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2).panel:h() -
                                    self._hud_panel:h()) / 2
                        ChatTranslator.mouse_pressed(self, button, x, y)
                    end)
        else
            HUDChat.mouse_pressed = ChatTranslator.mouse_pressed
        end

        Hooks:PostHook(HUDChat, "_on_focus", "ChatTranslator_HUDChat__on_focus", function(self)
            if ChatTranslator.settings.mouse_pointer and ChatTranslator.can_use_mouse_pointer and
                not self._mouse_pointer_active then
                local data = {
                    mouse_move = function(_, x, y)
                        return self:mouse_moved(managers.mouse_pointer:convert_mouse_pos(x, y))
                    end,
                    mouse_press = function(_, button, x, y)
                        return self:mouse_pressed(button, managers.mouse_pointer:convert_mouse_pos(x, y))
                    end,
                    mouse_release = function()
                    end,
                    mouse_click = function()
                    end,
                    mouse_double_click = function()
                    end,
                    id = "chat_translator_hudchat"
                }
                managers.mouse_pointer:use_mouse(data)
                self._mouse_pointer_active = true
            end
        end)

        Hooks:PostHook(HUDChat, "_loose_focus", "ChatTranslator_HUDChat__loose_focus", function(self)
            if self._mouse_pointer_active then
                managers.mouse_pointer:remove_mouse("chat_translator_hudchat")
                self._mouse_pointer_active = false
            end
        end)

        Hooks:PostHook(HUDChat, "remove", "ChatTranslator_HUDChat_remove", function(self)
            if self._mouse_pointer_active then
                managers.mouse_pointer:remove_mouse("chat_translator_hudchat")
                self._mouse_pointer_active = false
            end
        end)
    elseif RequiredScript == "lib/managers/hudmanagerpd2" then
        Hooks:PreHook(HUDManager, "setup_endscreen_hud", "ChatTranslator_HUDManager_setup_endscreen_hud", function(self)
            if self._hud_chat_ingame and self._hud_chat_ingame._mouse_pointer_active then
                managers.mouse_pointer:remove_mouse("chat_translator_hudchat")
                self._hud_chat_ingame._mouse_pointer_active = false
            end
        end)
    elseif RequiredScript == "lib/managers/menumanager" then
        Hooks:Add("LocalizationManagerPostInit", "ChatTranslator_LocalizationManagerPostInit", function(loc)
            for i = 1, #ChatTranslator.languages.name_ids do
                loc:add_localized_strings({
                    [ChatTranslator.languages.name_ids[i]] = ChatTranslator.languages.names[i] .. " (" ..
                        ChatTranslator.languages.codes[i] .. ")"
                })
            end

            for _, filename in pairs(file.GetFiles(ChatTranslator._mod_path .. "loc")) do
                local language = filename:match("^(.*).json$")
                if language and Idstring(language) and Idstring(language):key() == SystemInfo:language():key() then
                    loc:load_localization_file(ChatTranslator._mod_path .. "loc/" .. filename)
                    return
                end
            end

            loc:load_localization_file(ChatTranslator._mod_path .. "loc/english.json")
        end)

        Hooks:Add("MenuManagerSetupCustomMenus", "ChatTranslator_MenuManagerSetupCustomMenus",
            function(menu_manager, nodes)
                MenuHelper:NewMenu("chat_translator")
                MenuHelper:NewMenu("chat_translator_exclude")
            end)

        Hooks:Add("MenuManagerPopulateCustomMenus", "ChatTranslator_MenuManagerPopulateCustomMenus",
            function(menu_manager, nodes)
                function MenuCallbackHandler:chat_translator_language_callback(item)
                    ChatTranslator.settings.language = ChatTranslator.languages.codes[item:value()]
                end

                function MenuCallbackHandler:chat_translator_hud_callback(item)
                    ChatTranslator.settings.hud = item:value()

                    ChatTranslator.UpdateButtons()
                end

                function MenuCallbackHandler:chat_translator_mouse_pointer_callback(item)
                    ChatTranslator.settings.mouse_pointer = (item:value() == "on")
                end

                function MenuCallbackHandler:chat_translator_extend_chat_callback(item)
                    ChatTranslator.settings.extend_chat = (item:value() == "on")
                end

                function MenuCallbackHandler:chat_translator_back_callback(item)
                    ChatTranslator:CheckHUDCompatibility()
                    ChatTranslator:Save()
                end

                function MenuCallbackHandler:chat_translator_auto_translate_callback(item)
                    ChatTranslator.settings.auto_translate = (item:value() == "on")
                end

                function MenuCallbackHandler:chat_translator_exclude_callback(item)
                    local code = item:name():gsub("^chat_translator_exclude_", "")
                    ChatTranslator.settings.auto_exclude[code] = (item:value() == "on") or nil
                end

                function MenuCallbackHandler:chat_translator_exclude_back_callback(item)
                    ChatTranslator:Save()
                end

                MenuHelper:AddToggle({
                    id = "chat_translator_auto_translate",
                    title = "chat_translator_auto_translate_title",
                    desc = "chat_translator_auto_translate_desc",
                    callback = "chat_translator_auto_translate_callback",
                    value = ChatTranslator.settings.auto_translate,
                    menu_id = "chat_translator",
                    priority = 6
                })

                -- One toggle per common lobby language, listed alphabetically
                local added = {}
                for _, group in ipairs(ChatTranslator.HELP_GROUPS) do
                    for _, code in ipairs(group.codes) do
                        local base = ChatTranslator.BaseCode(code)
                        local name = ChatTranslator.languages.by_code[base]
                        if base and name and not added[base] then
                            added[base] = true
                            MenuHelper:AddToggle({
                                id = "chat_translator_exclude_" .. base,
                                title = "chat_translator_" .. name,
                                desc = "chat_translator_exclude_desc",
                                callback = "chat_translator_exclude_callback",
                                value = ChatTranslator.settings.auto_exclude[base] and true or false,
                                menu_id = "chat_translator_exclude"
                            })
                        end
                    end
                end

                local language_index = nil
                for i, value in ipairs(ChatTranslator.languages.codes) do
                    if value == ChatTranslator.settings.language then
                        language_index = i
                    end
                end

                MenuHelper:AddMultipleChoice({
                    id = "chat_translator_language",
                    title = "chat_translator_language_title",
                    description = "chat_translator_language_desc",
                    callback = "chat_translator_language_callback",
                    items = ChatTranslator.languages.name_ids,
                    value = language_index or 1,
                    menu_id = "chat_translator",
                    priority = 7
                })

                MenuHelper:AddMultipleChoice({
                    id = "chat_translator_hud",
                    title = "chat_translator_hud_title",
                    description = "chat_translator_hud_desc",
                    callback = "chat_translator_hud_callback",
                    items = {"chat_translator_hud_default", "chat_translator_hud_wolfhud", "chat_translator_hud_voidui",
                             "chat_translator_hud_vanillahud", "chat_translator_hud_auto"},
                    value = ChatTranslator.settings.hud,
                    menu_id = "chat_translator",
                    priority = 4
                })

                MenuHelper:AddDivider({
                    id = "chat_translator_divider_1",
                    size = 16,
                    menu_id = "chat_translator",
                    priority = 3
                })

                MenuHelper:AddToggle({
                    id = "chat_translator_mouse_pointer",
                    title = "chat_translator_mouse_pointer_title",
                    desc = "chat_translator_mouse_pointer_desc",
                    callback = "chat_translator_mouse_pointer_callback",
                    value = ChatTranslator.settings.mouse_pointer,
                    menu_id = "chat_translator",
                    priority = 2
                })

                MenuHelper:AddToggle({
                    id = "chat_translator_extend_chat",
                    title = "chat_translator_extend_chat_title",
                    desc = "chat_translator_extend_chat_desc",
                    callback = "chat_translator_extend_chat_callback",
                    value = ChatTranslator.settings.extend_chat,
                    menu_id = "chat_translator",
                    priority = 1
                })

                ChatTranslator.UpdateButtons()
            end)

        Hooks:Add("MenuManagerBuildCustomMenus", "ChatTranslator_MenuManagerBuildCustomMenus",
            function(menu_manager, nodes)
                nodes.chat_translator_exclude = MenuHelper:BuildMenu("chat_translator_exclude", {
                    back_callback = "chat_translator_exclude_back_callback"
                })
                nodes.chat_translator = MenuHelper:BuildMenu("chat_translator", {
                    back_callback = "chat_translator_back_callback"
                })
                MenuHelper:AddMenuItem(nodes.chat_translator, "chat_translator_exclude",
                    "chat_translator_exclude_title", "chat_translator_exclude_menu_desc",
                    "chat_translator_auto_translate", "after")
                MenuHelper:AddMenuItem(nodes.blt_options, "chat_translator", "chat_translator_title",
                    "chat_translator_desc")
            end)
    end
end

ChatTranslator:Setup()
