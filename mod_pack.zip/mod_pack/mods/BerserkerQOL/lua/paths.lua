BerserkerQOL.hook_paths = {
	["lib/units/beings/player/playerinventory"] = BerserkerQOL._path.."hooks/playerinventory.lua",
	["lib/managers/playermanager"] = BerserkerQOL._path.."hooks/playermanager.lua",
	["lib/player_actions/skills/playeractiontagteam"] = BerserkerQOL._path.."hooks/playeractiontagteam.lua",
	["lib/network/handlers/unitnetworkhandler"] = BerserkerQOL._path.."hooks/unitnetworkhandler.lua",
	["lib/units/beings/player/playerdamage"] = BerserkerQOL._path.."hooks/playerdamage.lua",
	["lib/network/base/basenetworksession"] = BerserkerQOL._path.."hooks/basenetworksession.lua",
}
