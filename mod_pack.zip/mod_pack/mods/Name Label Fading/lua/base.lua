local ThisModPath = ModPath
local ThisModPathIds = Idstring(ThisModPath):key()
local func1 = "F_" .. Idstring("func1::" .. ThisModPathIds):key()

local labelPos = Vector3()
local screenCenter = Vector3(640, 350, 0)
local distance = 0
local radius = 0
local menu = {}

_G.NameLabelFading = _G.NameLabelFading or {}
NameLabelFading.options = {}

function NameLabelFading:Load()
    self:LoadDefault()
    local file = io.open(SavePath .. "NameLabelFading.txt", "r")

    if file then
        for k, v in pairs(json.decode(file:read('*all')) or {}) do
            self.options[k] = v
        end
        file:close()
    end
end

function NameLabelFading:Save()
    local file = io.open(SavePath .. "NameLabelFading.txt", "w")
    if file then
        file:write(json.encode(self.options))
        file:close()
    end
end

function NameLabelFading:LoadDefault()
    self.options = {
        enable = true,
        inner_alpha = 60,
        outter_alpha = 100,
        inner_radius = 10,
        outter_radius = 50,
        highlight_enable = false,
        highlight = 100,
        localization = 'english',
    }
end

NameLabelFading:Load()

-- base.lua also runs on the menumanager pass, where HUDManager is not yet extended.
if HUDManager and HUDManager._update_name_labels then
Hooks:PostHook(HUDManager, "_update_name_labels", func1, function(self)
    if not NameLabelFading.options.enable then
        return
    end

    for _, data in ipairs(self._hud.name_labels) do
        local label_panel = data.panel
        label_panel:set_alpha(0)

        local centerX = label_panel:center_x()
        local centerY = label_panel:center_y()

        labelPos = Vector3(centerX, centerY, 0)

        radius = NameLabelFading:getOutterRadius()

        distance = mvector3.distance(labelPos, screenCenter)

        if distance < NameLabelFading:getInnerRadius() then
            if NameLabelFading.options.highlight_enable then
                label_panel:set_alpha(NameLabelFading:getHighlightAlpha())
            else
                label_panel:set_alpha(NameLabelFading:getInnerAlpha())
            end
        elseif distance >= NameLabelFading:getInnerRadius() and distance < radius then
            if NameLabelFading:getInnerAlpha() >= NameLabelFading:getOutterAlpha() then
                label_panel:set_alpha(math.clamp(1 - (distance / radius), NameLabelFading:getOutterAlpha(),
                    NameLabelFading:getInnerAlpha()))
            else
                label_panel:set_alpha(math.clamp(distance / radius, NameLabelFading:getInnerAlpha(),
                    NameLabelFading:getOutterAlpha()))
            end
        else
            label_panel:set_alpha(NameLabelFading:getOutterAlpha())
        end
        -- label_panel:set_visible(true);
    end

end)
end

Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_NameLabelFading", function(menu_manager)
    MenuHelper:LoadFromJsonFile(ThisModPath .. "options.txt", NameLabelFading, NameLabelFading.options)
end)


Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_NameLabelFading", function(menu_manager)

    MenuCallbackHandler.NameLabelFadingToggle = function(this, item)
        NameLabelFading.options.enable = item:value() == "on" or false
        NameLabelFading:SetEnabled(NameLabelFading.options.enable, NameLabelFading.options.highlight_enable)
    end

    MenuCallbackHandler.NameLabelFadingInnerAlpha = function(this, item)
        NameLabelFading.options.inner_alpha = item:value()

    end

    MenuCallbackHandler.NameLabelFadingOutterAlpha = function(this, item)
        NameLabelFading.options.outter_alpha = item:value()
    end

    MenuCallbackHandler.NameLabelFadingInnerRadius = function(this, item)
        local outterRadiusIndex = NameLabelFading:GetIndex("outter_radius")
        local outterRadiusItem = NameLabelFading:GetItem(outterRadiusIndex)
        local outterRadiusRowItem = outterRadiusItem._parameters.gui_node.row_items[outterRadiusIndex]
        if outterRadiusItem:value() < item:value() then
            outterRadiusItem:set_value(item:value())
            outterRadiusItem:reload(outterRadiusRowItem)
        end
        NameLabelFading.options.inner_radius = item:value()
    end

    MenuCallbackHandler.NameLabelFadingOutterRadius = function(this, item)
        if item:value() < NameLabelFading.options.inner_radius then
            item:set_value(NameLabelFading.options.inner_radius)
        end
        NameLabelFading.options.outter_radius = item:value()
    end

    MenuCallbackHandler.NameLabelFadingToggleHighLight = function(this, item)
        NameLabelFading.options.highlight_enable = item:value() == "on" or false
        NameLabelFading:SetEnabled(NameLabelFading.options.enable, NameLabelFading.options.highlight_enable)
    end

    MenuCallbackHandler.NameLabelFadingHighLightAlpha = function(this, item)
        NameLabelFading.options.highlight = item:value()
    end

    MenuCallbackHandler.NameLabelFadingSave = function(this)
        NameLabelFading:Save()
    end

    MenuCallbackHandler.NameLabelFadingReset = function(this, item)
        NameLabelFading:LoadDefault()
        for k, v in pairs(NameLabelFading.options) do
            MenuHelper:ResetItemsToDefaultValue(item, { [k] = true }, v)
        end
    end
end)

Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_NameLabelFading", function(menu_manager, nodes)
    NameLabelFading:InitMenu()
end)

function NameLabelFading:InitMenu()
    menu = MenuHelper:GetMenu("name_tag_fading_menu")
    local defaultDisabled = {}
    defaultDisabled.highlightTag = self:GetItem(self:GetIndex("setting_title_highlight"))
    defaultDisabled.radiusTag = self:GetItem(self:GetIndex("setting_title_radius"))
    defaultDisabled.alphaTag = self:GetItem(self:GetIndex("setting_title_alphas"))

    for _, item in pairs(defaultDisabled) do
        item:set_enabled(false)
    end

    self:SetEnabled(self.options.enable, self.highlight_enable)
end

function NameLabelFading:SetEnabled(isEnabled, highlightEnable)
    local generalItems = {}
    generalItems.inner_alpha = self:GetItem(self:GetIndex("inner_alpha"))
    generalItems.outter_alpha = self:GetItem(self:GetIndex("outter_alpha"))
    generalItems.inner_radius = self:GetItem(self:GetIndex("inner_radius"))
    generalItems.outter_radius = self:GetItem(self:GetIndex("outter_radius"))
    generalItems.highlight_enable = self:GetItem(self:GetIndex("highlight_enable"))

    for k, item in pairs(generalItems) do
        item:set_enabled(isEnabled)
    end

    local highlight = self:GetItem(self:GetIndex("highlight"))

    if isEnabled and highlightEnable then
        highlight:set_enabled(true)
    else
        highlight:set_enabled(false)
    end
end

function NameLabelFading:GetIndex(id)
    for index, item in pairs(menu._items_list) do
        if item._parameters.name == id then
            return index
        end
    end
end

function NameLabelFading:GetItem(index)
    return menu._items_list[index]
end

-- function NameLabelFading:getSetting(id_table, default)
--     if type(id_table) == "table" then
--         local entry = self.options
--         for i = 1, #id_table do
--             entry = entry[id_table[i]]
--             if entry == nil then
--                 self:print_log("Requested setting doesn't exists!  (id='" ..
--                     self:SafeTableConcat(id_table, "->") .. "', type='" .. (default and type(default) or "n/a") .. "') "
--                     , "error")
--                 return default
--             end
--         end
--         return entry
--     end
--     return default
-- end

-- localization, code learnt and copied from mod: More Weapon Stats
Hooks:Add('LocalizationManagerPostInit', 'LocalizationManagerPostInit_NameLabelFading', function(loc)
	local language_filename

	if not language_filename then
		for _, filename in pairs(file.GetFiles(ThisModPath .. 'loc/')) do
			local str = filename:match('^(.*).txt$')
			if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
				language_filename = filename
				break
			end
		end
	end

	if language_filename then
		loc:load_localization_file(ThisModPath .. 'loc/' .. language_filename)
	end
	loc:load_localization_file(ThisModPath .. 'loc/english.txt', false)
end)

function NameLabelFading:getInnerAlpha()
    return self.options.inner_alpha / 100
end

function NameLabelFading:getOutterAlpha()
    return self.options.outter_alpha / 100
end

function NameLabelFading:getInnerRadius()
    return self.options.inner_radius / 100 * 360
end

function NameLabelFading:getOutterRadius()
    return self.options.outter_radius / 100 * 360
end

function NameLabelFading:getHighlightAlpha()
    return self.options.highlight / 100
end
